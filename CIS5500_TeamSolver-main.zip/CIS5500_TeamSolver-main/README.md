# Project Description

Planning travel often requires back and forth between multiple platforms to book hotels and discover local attractions. This kind of tasks can sometimes be timeconsuming and boring. Our web application “Expedia Meets Yelp” solves this issue by combines hotel listings with local business information to make this overall process easier. In our platfiorm, users can easily search for hotels and see nearby businesses including restaurants and other point of attractions in a single platform.

# Dependencies

Docker works best on a MacOS operating system with the Chrome browser. If you have deployment issues, please refer to the alternate deployment instructions. 

# Deploying the app

Create a `.env` file in the `backend` directory of this project with database credentials:

   ```ini
   POSTGRES_USER=your_user
   POSTGRES_PASSWORD=your_password
   POSTGRES_SERVER=localhost
   POSTGRES_PORT=5432
   POSTGRES_DB=your_database
   ```

Then run: 

```bash
docker compose build --no-cache
docker compose up
```

Front end will be available at http://localhost:3000 
Backend Swagger can viewd at http://localhost:8000/docs

Deployed instance is available as well at http://ec2-54-227-0-21.compute-1.amazonaws.com:3000/ and http://ec2-54-227-0-21.compute-1.amazonaws.com:8000/docs respectively

# ALTERATE DEPLOYMENT INSTRUCTIONS AND OTHER INFORMATION ABOUT THE REPOSITORY

# Frontend

Frontend uses React.js for building user interface. We started off from Homework 3 frontend resources that was provided us. Frontend has 4 different pages

## Setup Instructions

1. **Install Dependencies**

   Install npm:

   ```bash
   npm install
   ```

2. **Run Frontend**

   Run Frontend:
   Navigate to frontend directory firts after that use the command below

   ```bash
   npm start
   ```
## Pages

• Landing Page: User inputs City, State, Categories and Search text here

• Results Page: Afetr user clicks search in Landing page, they are redericted to Results page which consists of results based on the input they selected

• Business Page: Once the user clicks on any of the business page, they are redirected to this page which contains more details about the business

• Hotels Page: Once the user clicks on any of the Hotels from results page, they are redirected to this page which contains more details about the business

• City Page: Information about City and Businesses in a City.


# Backend

This is a FastAPI application that interacts with a PostgreSQL database to perform complex SQL queries for a travel itinerary planning application. It allows users to find hotels and nearby businesses based on various criteria.

## Features

- **Search Hotels:** Find top-rated hotels in a city based on nearby restaurant ratings.
- **Nearby Businesses:** List nearby businesses matching user preferences.
- **Custom Itineraries:** Generate itineraries based on user interests.
- **Advanced Queries:** Utilize complex SQL queries for enhanced search capabilities.

## Backend Project Structure

```
project_root/backend
├── app/
│   ├── main.py
│   ├── core/
│   ├── db/
│   ├── models/
│   ├── schemas/
│   ├── api/
│   ├── tests/
│   └── alembic/
├── pyproject.toml
├── alembic.ini
├── .env
├── .gitignore
├── Dockerfile
├── docker-compose.yml
├── README.md
└── LICENSE
```

## Setup Instructions

### Prerequisites

- **Python 3.9+**
- **Docker and Docker Compose**
- **Poetry** (for dependency management)

### Installation

1. **Clone the Repository**

2. **Set Up Environment Variables**

   The `.env` file in the root directory has database credentials and is ready to go. Feel free to make modification if needed:

   ```ini
   POSTGRES_USER=your_user
   POSTGRES_PASSWORD=your_password
   POSTGRES_SERVER=localhost
   POSTGRES_PORT=5432
   POSTGRES_DB=your_database
   ```

3. **Install Dependencies**

   Install dependencies using Poetry:

   ```bash
   poetry install
   ```

### Running the Application

#### Using Docker Compose

1. **Build and Run the Containers**

   ```bash
   docker-compose up --build 
   ```

2. **Access the API**

   The API will be available at `http://localhost:8000`.

#### Without Docker

1. **Start the FastAPI Server**

   ```bash
   uvicorn app.main:app --reload
   ```

2. **Access the API**

   The API will be available at `http://127.0.0.1:8000`.

### API Documentation

Interactive API documentation is available at:

- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`


### Code Formatting and Linting

Ensure code quality using the following tools:

- **Black** (code formatting):

  ```bash
  black app/
  ```

- **isort** (import sorting):

  ```bash
  isort app/
  ```

- **Flake8** (linting):

  ```bash
  flake8 app/
  ```

### Deployment

For production deployment, consider using a WSGI server like Gunicorn with Uvicorn workers. Update the `Dockerfile` and `docker-compose.yml` accordingly.

### Database Schema

The database uses the following tables:

- `hotel`
- `business`
- `review`
- `category`
- `iscategory`
- `photo`

### Models and Schemas

Models are defined using SQLAlchemy ORM in `app/models/`, and Pydantic schemas are defined in `app/schemas/`.

### Alembic Migrations

Database migrations are managed using Alembic. The migration scripts are located in `app/alembic/versions/`.

## Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository.
2. Create a new branch (`git checkout -b feature/your-feature`).
3. Commit your changes (`git commit -m 'Add your feature'`).
4. Push to the branch (`git push origin feature/your-feature`).
5. Open a pull request.


**Note:** Replace placeholders like `your_user`, `your_password`, `your_database`, `your_username`, and `you@example.com` with your actual information.
