import React, { useState, useEffect } from "react";
import BusinessInfo from '../components/BusinessInfo';
import Reviews from '../components/Reviews';
import { Container, Grid2, Card, CardContent, Box, Typography, Divider, Rating } from '@mui/material';
import QuiltedImageList from '../components/QuiltedImageList'
import { useParams } from 'react-router-dom';
import axios from "axios";
import { useSearchParams } from 'react-router-dom';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
// import BusinessIcon from '@mui/icons-material/Folder';
import BusinessIcon from '@mui/icons-material/Business';
import BusinessMap from '../components/BusinessMap';
import ListItemButton from '@mui/material/ListItemButton';
import BusinessListItem from '../components/BusinessListItem';
import LazyTable from '../components/LazyTable';
const config = require('../config.json');

export default function BusinessPage() {
    const [searchParams] = useSearchParams();
    const { businessid } = useParams();
    const rating = searchParams.get('rating');
    // const format1 = {};
    const [photos, setPhotos] = useState([]);
    const [businessInfo, setBusinessInfo] = useState([]);

    const [nearestHotels, setNearestHotels] = useState([]);
    const [nightlife, setNghtlife] = useState([]);
    const [topBusinesses, setTopBusinesses] = useState([]);
    const [reviews, setReviews] = useState([]);



    useEffect(() => {
        axios
            .get(`http://${config.server_host}:${config.server_port}/api/v1/photos?bid=${businessid}`)
            .then((response) => {
                const d = response.data;
                setPhotos(d);
                // console.log(d)
                // console.log(stateLookup)
            })
            .catch((error) => {
                console.error("Error fetching states:", error);
            });
    }, []);

    useEffect(() => {
        let isMounted = true;

        axios
            .get(`http://${config.server_host}:${config.server_port}/api/v1/business-info?bid=${businessid}`)
            .then((response) => {
                const d = response.data;

                if (isMounted) {
                    setBusinessInfo(d);
                }
                // console.log(businessInfo)
                // console.log(stateLookup)
            })

        return () => {
            isMounted = false; // Cleanup to prevent state updates if the component is unmounted
        };
    }, []);





    // var route = 'api/v1/top_nearest_hotels';
    // console.log('binfo')
    // console.log(businessInfo)

    useEffect(() => {
        // console.log(`businessinfo.length:${businessInfo.length}`)
        if (businessInfo.length === 0) return;

        let isMounted = true; // Flag to prevent state updates if the component is unmounted

        fetch(`http://${config.server_host}:${config.server_port}/api/v1/top_nearest_hotels?distance=${10}&lat=${parseFloat(businessInfo.latitude)}&lon=${parseFloat(businessInfo.longitude)}`)
            //   fetch(`/${route}?city=${city}&state=${state}&category=${category}`)
            .then(res => res.json())
            .then(resJson => {
                setNearestHotels(resJson)
            });

        // fetch(`http://${config.server_host}:${config.server_port}/api/v1/top_nearest_businesses?distance=${10}&lat=${businessInfo.latitude}&lon=${businessInfo.longitude}`)
        //     //   fetch(`/${route}?city=${city}&state=${state}&category=${category}`)
        //     .then(res => res.json())
        //     .then(resJson => {
        //         setTopBusinesses(resJson)
        //     });

        fetch(`http://${config.server_host}:${config.server_port}/api/v1/top_nearest_category_businesses?category=${"Nightlife"}&distance=${10}&lat=${businessInfo.latitude}&lon=${businessInfo.longitude}`)
            //   fetch(`/${route}?city=${city}&state=${state}&category=${category}`)
            .then(res => res.json())
            .then(resJson => {
                setNghtlife(resJson)
            });
        return () => {
            isMounted = false; // Cleanup to prevent state updates if the component is unmounted
        };

    }, [businessInfo]);

    // useEffect(() => {
    //     fetch(`http://${config.server_host}:${config.server_port}/api/v1/reviews?bid=${businessid}`)
    //         //   fetch(`/${route}?city=${city}&state=${state}&category=${category}`)
    //         .then(res => res.json())
    //         .then(resJson => {
    //             setReviews(resJson)
    //         });
    // }, []);


    useEffect(() => {
        if (businessInfo.length === 0) return;

        let isMounted = true; // Flag to prevent state updates if the component is unmounted


        fetch(`http://${config.server_host}:${config.server_port}/api/v1/top_nearest_businesses?city=${businessInfo.city}&state=${businessInfo.state}&distance=${10}&lat=${businessInfo.latitude}&lon=${businessInfo.longitude}`)
            //   fetch(`/${route}?city=${city}&state=${state}&category=${category}`)
            .then(res => res.json())
            .then(resJson => {
                setTopBusinesses(resJson)
            });


        return () => {
            isMounted = false; // Cleanup to prevent state updates if the component is unmounted
        };

    }, [businessInfo]);


    const reviewColumns = [
        {
            field: 'name',
            headerName: 'User',

        },
        {
            field: 'stars',
            headerName: 'Stars',
            renderCell: (row) => <Rating name="read-only" value={row.stars} readOnly />
        },
        {
            field: 'text',
            headerName: 'Review',

        },
        {
            field: 'date',
            headerName: 'Date',
        },
    ];


    return (
        <div>
            <Container>
                <Grid2 xs={12} maxHeight={'500px'}>
                    <QuiltedImageList photos={photos} />
                </Grid2>
                <Grid2 xs={12}>
                    <BusinessInfo name={businessInfo.name} rating={rating} city={businessInfo.city} state={businessInfo.state} address={businessInfo.address} latitude={businessInfo.latitude} longitude={businessInfo.longitude} zoom={15} num_ratings={businessInfo.num_ratings} />
                </Grid2>
                <Card>
                    <CardContent>
                        <Box sx={{ flexGrow: 1 }}>
                            <Grid2 container spacing={3}>

                                <Grid2 size={4}>
                                    <Typography variant="h4">Top Nearest Businesses</Typography>
                                    <List dense={true}>
                                        {topBusinesses.slice(0, 10).map((business, index) => (
                                            <BusinessListItem key={index} business={business} category={'Business'} />
                                        ))}
                                    </List>
                                </Grid2>
                                <Grid2 size={4}>
                                    <Typography variant="h4">Top Nearest Hotels</Typography>
                                    <List dense={true}>
                                        {nearestHotels.slice(0, 10).map((business, index) => (
                                            <BusinessListItem key={index} business={business} category={'Hotels'} />
                                        ))}
                                    </List>
                                </Grid2>
                                <Grid2 size={4}>
                                    <Typography variant="h4">Top Nearest Nightlife</Typography>
                                    <List dense={true}>
                                        {nightlife.slice(0, 10).map((business, index) => (
                                            <BusinessListItem key={index} business={business} category={'Nightlife'} />
                                        ))}
                                    </List>
                                </Grid2>
                            </Grid2>
                        </Box>
                    </CardContent>
                </Card>
                {/* <Grid2 xs={12}> */}
                {/* <Reviews /> */}
                {/* </Grid2> */}

                <Divider />
                {/* TODO (TASK 16): add a h2 heading, LazyTable, and divider for top albums. Set the LazyTable's props for defaultPageSize to 5 and rowsPerPageOptions to [5, 10] */}
                <h2>Reviews</h2>
                <LazyTable route={`http://${config.server_host}:${config.server_port}/api/v1/reviews`} columns={reviewColumns} bid={businessid} defaultPageSize={5} rowsPerPageOptions={[5, 10, 15, 20]} />
                <Divider />

            </Container>
        </div>
    );
}

