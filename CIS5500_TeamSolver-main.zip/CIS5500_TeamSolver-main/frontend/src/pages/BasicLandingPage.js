import React, { useState, useEffect } from "react";
import axios from "axios";
import { Container, Box, TextField, MenuItem, Typography, Card, CardMedia, CardContent, CardActionArea } from "@mui/material";
import Grid from "@mui/material/Grid2"; // Import Grid from the experimental component
import { useNavigate } from 'react-router-dom';
import Button from '@mui/material/Button';
import ClickableCard from "../components/ClickableCard";
import Plot from "react-plotly.js";
const topCities = [
  { name: "Tampa", state_long: 'Florida', state: 'FL', lat: 27.964157, lon: -82.452606, description: "Tampa is a city in Florida on the Gulf Coast, and is the largest city in the Tampa Bay area. It's known for its many attractions, including the Tampa Riverwalk, Busch Gardens, and the Florida Aquarium. ", image: "https://images.locationscout.net/2019/11/tampa-skyline-usa-gwjv.webp?h=1400&q=80" },
  { name: "Philadelphia", state_long: 'Pennsylvania', state: 'PA', lat: 39.952583, lon: -75.165222, description: 'Philadelphia is known as the "Birthplace of America" and was the first capital of the United States. It was the site of the First Continental Congress and the Constitutional Convention. The city is also home to many historical sites, including Independence Hall, the Liberty Bell, and the National Constitution Center.', image: "https://t3.ftcdn.net/jpg/01/65/57/98/360_F_165579884_ut8QbWsiuUXJujEuc8TaIzzIGSYY0Jrk.jpg" },
  { name: "Tucson", state_long: 'Arizona', state: 'AZ', lat: 32.253460, lon: -110.911789, description: "Tucson, Arizona is a city known for its culture, outdoor activities, and dining. Tucson is in the Sonoran Desert, surrounded by mountains and forests, and is 65 miles from Mexico. Tucson is a great place for hiking, biking, swimming, tennis, and golfing. It's also known for its outdoor adventures at Saguaro National Park, Mt. Lemmon, and Sabino Canyon.", image: "https://media.gettyimages.com/id/501834601/photo/tucson-arizona-skyline-cityscape-and-santa-catalina-mountains-at-sunset.jpg?s=612x612&w=gi&k=20&c=WEPqhg5hpkf1umxfyLTizd-p9jdkORJ90u_6qclXYjk=" },
  { name: "Reno", state_long: 'Nevada', state: 'NV', lat: 39.530895, lon: -119.814972, description: "Reno is a city in Nevada, known as \"The Biggest Little City in the World\". It's the most populated city in Nevada outside of the Las Vegas Valley, and the third most populated city in the state. eno has several districts, including the Riverwalk District, which has shopping, eating, entertainment, and bike paths, and the Midtown District, which has indie stores, artisanal shops, and innovative dining.", image: "https://www.wildnatureimages.com/images/xl/071006-134-Reno-Nevada-Skyline.jpg" },
  { name: "Nashville", state_long: 'Tennessee', state: 'TN', lat: 36.174465, lon: -86.767960, description: "Nashville is located in Middle Tennessee on the Cumberland River. Nashville is known for its country and western music, and is home to the Grand Ole Opry, the Country Music Hall of Fame, and many major record labels.", image: "https://images.fineartamerica.com/images/artworkimages/mediumlarge/3/vibrant-lights-over-the-nashville-skyline-nashville-tennessee-panorama-gregory-ballos.jpg" },
  { name: "Indianapolis", state_long: 'Indiana', state: 'IN', lat: 39.791000, lon: -86.148003, description: "Indianapolis is in the central part of Indiana, on the White River where it meets Fall Creek. Indianapolis is known for the Indianapolis 500 automobile race, and is home to the global headquarters of companies like Eli Lilly and Company. Indianapolis has many attractions, including the Indianapolis Zoo, the Eiteljorg Museum of American Indians & Western Art, Monument Circle, Newfields, and The Children's Museum of Indianapolis.", image: "https://www.invitedclubs.com/globalassets/skyline-club---indianapolis/_images/photoshelter-2023/skyline-indy_catiejasonssneakpeek-catiejason-0253_1920_1200.jpg?format=webp" },
  { name: "Santa Barbara", state_long: 'California', state: 'CA', lat: 34.420830, lon: -119.698189, description: "Santa Barbara is on the Central Coast of Southern California, 92 miles north of Los Angeles and 332 miles south of San Francisco. Santa Barbara is known as \"The American Riviera\" and is known for its beaches, Spanish architecture, and Mediterranean-like climate.", image: "https://t4.ftcdn.net/jpg/00/65/74/27/360_F_65742708_vgKY6y5cWjqFHFNZXhCrbVg0cMAInRMZ.jpg" },
  { name: "New Orleans", state_long: 'Louisiana', state: 'LA', lat: 29.951065, lon: -90.071533, description: "New Orleans is world-renowned for its distinctive music, Creole cuisine, unique dialects, and its annual celebrations and festivals, most notably Mardi Gras. The historic heart of the city is the French Quarter, known for its French and Spanish Creole architecture and vibrant nightlife along Bourbon Street.", image: "https://images.fineartamerica.com/images/artworkimages/mediumlarge/2/1-new-orleans-skyline-lightkey.jpg" },
  // Add more city data if needed
];
const config = require('../config.json');

export default function BasicLandingPage() {
  const [states, setStates] = useState([]);
  const [cities, setCities] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedState, setSelectedState] = useState("");
  const [selectedCity, setSelectedCity] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [searchText, setSearchText] = useState("");
  // const [stateLookup, setStateLookup] = useState("");
  // Fetch states on component mount
  useEffect(() => {
    axios
      .get(`http://${config.server_host}:${config.server_port}/api/v1/states`)
      .then((response) => {
        const d = response.data;
        setStates(d);
        // console.log(d)
        // console.log(stateLookup)
      })
      .catch((error) => {
        console.error("Error fetching states:", error);
      });
  }, []);

  const stateLookup = {};
  states.map(item => { stateLookup[item.state] = item.state_desc });
  // setStateLookup(acc);

  // Fetch categories on component mount
  // useEffect(() => {
  //   axios
  //     .get(`http://${config.server_host}:${config.server_port}/api/v1/categories`)
  //     .then((response) => {
  //       setCategories(response.data);
  //     })
  //     .catch((error) => {
  //       console.error("Error fetching categories:", error);
  //     });
  // }, []);

  // Fetch cities when a state is selected
  const handleStateChange = (state) => {
    setSelectedState(state);
    // console.log(`state=${stateLookup[state]}`)
    setSelectedCity(""); // Reset city selection
    setSelectedCategory("");
    if (state) {
      axios
        .get(`http://${config.server_host}:${config.server_port}/api/v1/cities?state=${state}`)
        .then((response) => {
          setCities(response.data);
        })
        .catch((error) => {
          console.error("Error fetching cities:", error);
        });
    } else {
      setCities([]); // Clear cities if no state is selected
    }
  };

  // Fetch cities when a state is selected
  const handleCityChange = (city) => {
    setSelectedCity(city);
    setSelectedCategory(""); // Reset city selection
    if (city) {
      axios
        .get(`http://${config.server_host}:${config.server_port}/api/v1/city-categories?state=${selectedState}&city=${city}`)
        .then((response) => {
          const d = response.data
          // d.push({
          //   "category": "Hotels"
          // })
          setCategories(d);
        })
        .catch((error) => {
          console.error("Error fetching cities:", error);
        });
    } else {
      setCategories([]); // Clear cities if no state is selected
    }
  };


  const navigate = useNavigate();

  const handleClick = () => {
    // console.log(searchText)
    navigate(`/results/${selectedCity}/${selectedState}/${stateLookup[selectedState]}/${selectedCategory}/0?search-text=${searchText}`);
  };

  const handleClickCity = (city, state) => {
    // console.log(searchText)
    navigate(`/city/${city}/${state}`);
  };
  // return (<button onClick={handleClick}>Go to Results</button>
  // );

  return (
    <Container>
      <Box my={4}>
        <Typography variant="h4" gutterBottom>
          Travel Destinations
        </Typography>
        <Grid container spacing={2} alignItems="center">
          {/* State Dropdown */}
          <Grid xs={12} sm={3}>
            <TextField
              select
              label="State"
              fullWidth
              style={{ minWidth: 200, width: '100%' }}
              value={selectedState}
              onChange={(e) => handleStateChange(e.target.value)}
            >
              <MenuItem value="" disabled>
                Select a state
              </MenuItem>
              {states.map((state, index) => (
                <MenuItem key={index} value={state.state}>
                  {state.state_desc}
                </MenuItem>
              ))}
            </TextField>
          </Grid>

          {/* City Dropdown */}
          <Grid xs={12} sm={3}>
            <TextField
              select
              label="City"
              fullWidth
              style={{ minWidth: 200, width: '100%' }}
              value={selectedCity}
              onChange={(e) => handleCityChange(e.target.value)}
              disabled={!selectedState}
            >
              <MenuItem value="" disabled>
                Select a city
              </MenuItem>
              {cities.map((city, index) => (
                <MenuItem key={index} value={city.city}>
                  {city.city}
                </MenuItem>
              ))}
            </TextField>
          </Grid>

          {/* Category Dropdown */}
          <Grid xs={12} sm={3}>
            <TextField
              select
              label="Category"
              fullWidth
              style={{ minWidth: 200, width: '100%' }}
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              disabled={!selectedCity}
            >
              <MenuItem value="" disabled>
                Select a category
              </MenuItem>
              {categories.map((category, index) => (
                <MenuItem key={index} value={category.category}>
                  {category.category}
                </MenuItem>
              ))}
            </TextField>
          </Grid>

          {/* Search Box */}
          <Grid xs={12} sm={3}>
            <TextField label="Search" fullWidth sx={{ minWidth: 320 }} value={searchText} onChange={(e) => setSearchText(e.target.value)} />
          </Grid>
          <Button variant="contained" onClick={handleClick} disabled={!selectedCategory}>Search</Button>
        </Grid>
      </Box>
      <Box my={4}>
        <Typography variant="h4" gutterBottom>
          Top 10 US City Destinations
        </Typography>
        <Grid container spacing={4}>
          {topCities.map((city, index) => (
            <ClickableCard city={city} />
          ))}
        </Grid>
      </Box>
      <Card>
        {/* <Plot
          data={[
            {
              x: [1, 2, 3, 4, 6, 8, 10, 12, 14, 16, 18],
              y: [32, 37, 40.5, 43, 49, 54, 59, 63.5, 69.5, 73, 74],
              mode: "markers",
              type: "scatter",
            },
          ]}
          layout={{
            title: "Growth Rate in Boys",
            xaxis: {
              title: "Age (years)",
            },
            yaxis: {
              title: "Height (inches)",
            },
            margin: {
              // t: 1,
              // b: 50
            },
            paper_bgcolor: '#eee'

          }}
        /> */}
      </Card>
    </Container>

  );
}