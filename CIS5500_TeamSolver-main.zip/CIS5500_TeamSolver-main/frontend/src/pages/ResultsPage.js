import { useEffect, useState } from 'react';
import { Container } from '@mui/material';
import { useParams } from 'react-router-dom';
import ToggleButton from '@mui/material/ToggleButton';
// import Stack from '@mui/material/Stack';
import * as React from 'react';
// import Button from '@mui/material/Button';
import { useNavigate } from 'react-router-dom';
import { useTheme } from '@mui/material/styles';
// import Rating from '@mui/material/Rating';
import { useSearchParams } from 'react-router-dom';
import Result from '../components/Result'

const config = require('../config.json');

export default function ResultsPage() {
    const navigate = useNavigate();
    const theme = useTheme();
    const primary = theme.palette.primary.main;
    const { city, state, state_long, category, sortv } = useParams();
    const [business_hotel, setBusiness_Hotels] = useState([]);
    // const [photos, setPhotos] = useState([]);


    const [searchParams] = useSearchParams();

    const stext = searchParams.get('search-text');
    // console.log(`stext = ${stext}`)
    let route = 'api/v1/hotels_random';
    let img_val = '/free_photos/hotel.jpg';

    if (category === 'Hotels') {
        img_val = '/free_photos/hotel.jpg';
        if (sortv === '1') {
            route = 'api/v1/hotels_low_rated';
        }
        else if (sortv === '2') {
            route = 'api/v1/hotels_high_rated';
        }
        else {
            route = 'api/v1/hotels_random';
        }
    }
    else {
        img_val = '/free_photos/business.jpg';
        if (sortv === '1') {
            route = 'api/v1/business_low_rated';
        }
        else if (sortv === '2') {
            route = 'api/v1/business_high_rated';
        }
        else {
            route = 'api/v1/business_random';
        }
    }
    useEffect(() => {
        fetch(`http://${config.server_host}:${config.server_port}/${route}?city=${city}&state=${state}&category=${category}&stext=${stext}&state_long=${state_long}`)
            //   fetch(`/${route}?city=${city}&state=${state}&category=${category}`)
            .then(res => res.json())
            .then(resJson => {
                setBusiness_Hotels(resJson)
            });
    }, []);
    const format1 = {};
    return (
        <div style={{ position: 'relative', height: '100%' }}>
            <h3 style={{
                marginTop: '50px',
                textAlign: 'center',
                fontSize: '25px',
                alignSelf: 'flex-start'
            }}>
                {category.toUpperCase()} RESULTS

                <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                    <ToggleButton value="Sort"
                        onClick={() => {
                            navigate(`/results/${city}/${state}/${state_long}/${category}/2/?search-text=${stext}`);
                            window.location.reload();
                        }}
                        style={{
                            backgroundColor: sortv === '2' ? primary : 'white',
                            right: '10px'
                        }}>
                        Sort by <br />High rating </ToggleButton>

                    <ToggleButton value="Sort"
                        onClick={() => {
                            navigate(`/results/${city}/${state}/${state_long}/${category}/1/?search-text=${stext}`);
                            window.location.reload();
                        }}
                        style={{
                            backgroundColor: sortv === '1' ? primary : 'white',
                            right: '10px'
                        }}>
                        Sort by <br />Low rating </ToggleButton>
                </div>
            </h3>

            <Container style={format1}>
                {business_hotel.map((eachone) =>
                    <Result state={state} city={city} id={eachone.id} name={eachone.name} rating={eachone.rating} address={eachone.address} img_val={img_val} category={category} city_code={eachone.citycode}></Result>
                )}
            </Container>
        </div>
    );
}
