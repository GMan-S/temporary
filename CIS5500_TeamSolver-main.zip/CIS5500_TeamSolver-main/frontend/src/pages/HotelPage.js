import React, { useState, useEffect } from "react";
import BusinessInfo from '../components/BusinessInfo';
import Reviews from '../components/Reviews';
import { Container, Grid2, Box, Card, CardContent, Typography } from '@mui/material';
// import QuiltedImageList from '../components/QuiltedImageList'
// import Rating from '@mui/material/Rating';
import { useParams } from 'react-router-dom';
import ImageList from '@mui/material/ImageList';
import ImageListItem from '@mui/material/ImageListItem';
import axios from "axios";
import { useSearchParams } from 'react-router-dom';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import FolderIcon from '@mui/icons-material/Folder';
import BusinessMap from '../components/BusinessMap';
import ListItemButton from '@mui/material/ListItemButton';
import Plot from "react-plotly.js";
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import BusinessListItem from "../components/BusinessListItem";

const config = require('../config.json');

function srcset(image, size, rows = 1, cols = 1) {
    return {
        src: `${image}?w=${size * cols}&h=${size * rows}&fit=crop&auto=format`,
        srcSet: `${image}?w=${size * cols}&h=${size * rows
            }&fit=crop&auto=format&dpr=2 2x`,
    };
}

function generate(element) {
    return [0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((value) =>
        React.cloneElement(element, {
            key: value,
        }),
    );
}

function clickHandle() {
    return true
}
export default function HotelPage() {


    const [searchParams] = useSearchParams();
    const { city_code, hotel_code } = useParams();
    const rating = searchParams.get('rating');
    // const format1 = {};
    const [hotelInfo, setHotelInfo] = useState([]);
    const [restaurants, setRestaurants] = useState([]);
    const [nightlife, setNghtlife] = useState([]);
    const [topBusinesses, setTopBusinesses] = useState([]);

    useEffect(() => {
        let isMounted = true;

        axios
            .get(`http://${config.server_host}:${config.server_port}/api/v1/hotel-info?hcode=${hotel_code}&ccode=${city_code}`)
            .then((response) => {
                const d = response.data;
                if (isMounted) {
                    setHotelInfo(d);
                }
                // console.log(d)
                // console.log(stateLookup)
            })
            .catch((error) => {
                console.error("Error fetching states:", error);
            });

        return () => {
            isMounted = false; // Cleanup to prevent state updates if the component is unmounted
        };
    }, []);
    const businesses = [
        { name: 'Business 1', latitude: 40.7128, longitude: -74.0060 },
        // { name: 'Business 2', latitude: 34.0522, longitude: -118.2437 },
        // { name: 'Business 3', latitude: 41.8781, longitude: -87.6298 },
        // Add more businesses as needed
    ];
    // console.log(`hotelrating:${hotelInfo.hotelrating}`)
    // console.log(`rating=${rating}`)
    const itemData = [
        {
            img: 'https://www.momondo.com/himg/dc/3d/88/ice-2949960-100077666-407139.jpg',
            title: 'Breakfast',
            rows: 2,
            cols: 2,
        },
        {
            img: 'https://3.imimg.com/data3/JV/KJ/MY-15827078/hotels-booking.jpg',
            title: 'Burger',
        },
        {
            img: 'https://orlandovacation.com/cdn/shop/files/Hilton_Lake_Buena_Vista_Lazy_River_Aerial_Image.png?v=1719325854&width=2400',
            title: 'Camera',
        },
        {
            img: 'https://cdn.britannica.com/96/115096-050-5AFDAF5D/Bellagio-Hotel-Casino-Las-Vegas.jpg',
            title: 'Coffee',
            cols: 2,
        },
        {
            img: 'https://drupal-prod.visitcalifornia.com/sites/default/files/styles/fluid_1920/public/2023-11/VC_SEO_Los-Angeles-Hotels_Freehand-Los-Angeles_HERO_SUPPLIED_1280x640.jpg.webp?itok=REEcffaV',
            title: 'Hats',
            cols: 2,
        },
        {
            img: 'https://www.cuddlynest.com/blog/wp-content/uploads/2022/02/best-orlando-hotels-scaled.jpg',
            title: 'Honey',
            author: '@arwinneil',
            rows: 2,
            cols: 2,
        },
        {
            img: 'https://i.pinimg.com/736x/72/12/78/72127877af37d24057aa557e632f760b.jpg',
            title: 'Basketball',
        },
        {
            img: 'https://hips.hearstapps.com/hmg-prod/images/villa-d-este-view-from-the-swimming-pool-2-1-658d24dc6688b.jpg',
            title: 'Fern',
        },
    ]


    useEffect(() => {
        // console.log(`hotelInfo.length:${hotelInfo.length}`)
        if (hotelInfo.length === 0) return;

        let isMounted = true; // Flag to prevent state updates if the component is unmounted

        fetch(`http://${config.server_host}:${config.server_port}/api/v1/closest_restaurants?category=${"Restaurants"}&distance=${10}&lat=${hotelInfo.latitude}&lon=${hotelInfo.longitude}`)
            //   fetch(`/${route}?city=${city}&state=${state}&category=${category}`)
            .then(res => res.json())
            .then(resJson => {
                setRestaurants(resJson)
            });

        // fetch(`http://${config.server_host}:${config.server_port}/api/v1/top_nearest_businesses?distance=${10}&lat=${hotelInfo.latitude}&lon=${hotelInfo.longitude}`)
        //     //   fetch(`/${route}?city=${city}&state=${state}&category=${category}`)
        //     .then(res => res.json())
        //     .then(resJson => {
        //         setTopBusinesses(resJson)
        //     });

        fetch(`http://${config.server_host}:${config.server_port}/api/v1/top_nearest_category_businesses?category=${"Nightlife"}&distance=${10}&lat=${hotelInfo.latitude}&lon=${hotelInfo.longitude}`)
            //   fetch(`/${route}?city=${city}&state=${state}&category=${category}`)
            .then(res => res.json())
            .then(resJson => {
                setNghtlife(resJson)
            });
        return () => {
            isMounted = false; // Cleanup to prevent state updates if the component is unmounted
        };

    }, [hotelInfo]);

    useEffect(() => {
        if (hotelInfo.length === 0) return;

        let isMounted = true; // Flag to prevent state updates if the component is unmounted


        fetch(`http://${config.server_host}:${config.server_port}/api/v1/top_nearest_businesses?city=${hotelInfo.city}&state=${hotelInfo.state}&distance=${10}&lat=${hotelInfo.latitude}&lon=${hotelInfo.longitude}`)
            //   fetch(`/${route}?city=${city}&state=${state}&category=${category}`)
            .then(res => res.json())
            .then(resJson => {
                setTopBusinesses(resJson)
            });


        return () => {
            isMounted = false; // Cleanup to prevent state updates if the component is unmounted
        };

    }, [hotelInfo]);

    return (
        <div>
            <Container>

                <Grid2 xs={12} maxHeight={'500px'}>
                    <ImageList
                        sx={{ width: 500, height: 500 }}
                        variant="quilted"
                        cols={4}
                        rowHeight={121}
                        style={{ width: '100%', height: '10%' }}
                    >
                        {itemData.map((item) => (
                            <ImageListItem key={item.img} cols={item.cols || 1} rows={item.rows || 1}>
                                <img
                                    {...srcset(item.img, 121, item.rows, item.cols)}
                                    alt={item.title}
                                    loading="lazy"
                                />
                            </ImageListItem>
                        ))}
                    </ImageList>
                </Grid2>
                <Grid2 xs={12} size={12}>
                    <BusinessInfo name={hotelInfo.hotelname} rating={rating} latitude={hotelInfo.latitude} longitude={hotelInfo.longitude} zoom={15} />
                </Grid2>
                <Card>
                    <CardContent>
                        <Box sx={{ flexGrow: 1 }}>
                            <Grid2 container spacing={3}>

                                <Grid2 size={4}>
                                    <Typography variant="h4">Top Nearest Businesses</Typography>
                                    <List dense={true}>
                                        {topBusinesses.slice(0, 10).map((business, index) => (
                                            <BusinessListItem key={index} business={business} category={'Business'} />
                                        ))}
                                    </List>
                                </Grid2>
                                <Grid2 size={4}>
                                    <Typography variant="h4">Top Nearest Restaurants</Typography>
                                    <List dense={true}>
                                        {restaurants.slice(0, 10).map((business, index) => (
                                            <BusinessListItem key={index} business={business} category={'Restaurants'} />
                                        ))}
                                    </List>
                                </Grid2>
                                <Grid2 size={4}>
                                    <Typography variant="h4">Top Nearest Nightlife</Typography>
                                    <List dense={true}>
                                        {nightlife.slice(0, 10).map((business, index) => (
                                            <BusinessListItem key={index} business={business} category={'Nightlife'} />
                                        ))}
                                    </List>
                                </Grid2>
                            </Grid2>
                        </Box>
                    </CardContent>
                </Card>
                <MapContainer >
                </MapContainer>
            </Container>
        </div>
    );
}

