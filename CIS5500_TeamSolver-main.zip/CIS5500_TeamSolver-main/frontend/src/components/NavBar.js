import { AppBar, Toolbar, Typography } from '@mui/material'
import IconButton from '@mui/material/IconButton';
import { NavLink } from 'react-router-dom';
import PublicSharpIcon from '@mui/icons-material/PublicSharp';

// The hyperlinks in the NavBar contain a lot of repeated formatting code so a
// helper component NavText local to the file is defined to prevent repeated code.
function NavText({ href, text, isMain }) {
  return (
    <Typography
      variant={isMain ? 'h5' : 'h7'}
      noWrap
      style={{
        marginRight: '30px',
        fontFamily: 'BlinkMacSystemFont',
        fontWeight: 700,
        letterSpacing: '.1rem',
      }}
    >
      <NavLink
        to={href}
        style={{
          color: 'inherit',
          textDecoration: 'none',
        }}
      >
        {text}
      </NavLink>
    </Typography>
  )
}

// Here, we define the NavBar. Note that we heavily leverage MUI components
// to make the component look nice. Feel free to try changing the formatting
// props to how it changes the look of the component.
export default function NavBar() {
  return (
    <AppBar position='static'
      style={{ height: '90px', justifyContent: 'center' }}>
      <Toolbar >
        <IconButton edge="start" color="inherit" aria-label="PublicSharp" style={{ alignItems: 'center' }}>
          <PublicSharpIcon />
        </IconButton>
        <NavText href='/' text='Expedia Meets Yelp' isMain />
      </Toolbar>
    </AppBar>
  );
}
