import React from 'react';
import { Card, CardMedia, CardActionArea, CardContent, Typography } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import Grid from "@mui/material/Grid2";
const ClickableCard = ({ city }) => {
    const navigate = useNavigate();
    const handleClick = () => {
        navigate(`/city/${city.name}/${city.state}?state_long=${city.state_long}&lat=${city.lat}&lon=${city.lon}&description=${city.description}`);
    };

    // const handleClickCity = (city, state) => {
    //     console.log(searchText)
    //     navigate(`/city/${city}/${state}`);
    //   };

    return (
        <Grid size={3}>
            <Card>
                <CardActionArea onClick={handleClick}>
                    <CardMedia component="img" height="140" image={city.image} alt={city.name} />
                    <CardContent>
                        <Typography variant="h6">{city.name}</Typography>
                    </CardContent>
                </CardActionArea>
            </Card>
        </Grid>
    );
};

export default ClickableCard;
