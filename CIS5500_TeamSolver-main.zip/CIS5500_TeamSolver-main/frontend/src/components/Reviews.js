import React from 'react';
import { Card, CardContent, Typography, List, ListItem, ListItemText } from '@mui/material';

function Reviews() {
    const reviews = [
        {
            user: 'John Doe',
            text: 'Great burgers, awesome shakes!',
        },
        {
            user: 'Jane Smith',
            text: 'Loved the atmosphere and the food.',
        },
    ];

    return (
        <Card>
            <CardContent>
                <Typography variant="h6">Reviews</Typography>
                <List>
                    {reviews.map((review, index) => (
                        <ListItem key={index}>
                            <ListItemText
                                primary={review.user}
                                secondary={review.text}
                            />
                        </ListItem>
                    ))}
                </List>
            </CardContent>
        </Card>
    );
}

export default Reviews;
