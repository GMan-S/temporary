import React from 'react';
import { Card, CardContent, Typography, Grid2 } from '@mui/material';
import Rating from '@mui/material/Rating';
import BusinessMap from './BusinessMap';
function BusinessInfo({ name, city, state, address, description, rating, latitude, longitude, zoom, num_ratings }) {
    // console.log(`latitude:${latitude} and longitude:${longitude}`);
    return (

        < Card >
            <CardContent>
                <Grid2 container spacing={2}>
                    <Grid2 size={6}>
                        <Typography variant="h4">{name}</Typography>
                        <Typography variant="h6">
                            Ratings: <Rating name="read-only" value={parseInt(rating)} readOnly />
                        </Typography>
                        <Typography variant="body2">{num_ratings} reviews</Typography>
                        <Typography variant="body2">{description}</Typography>
                    </Grid2>
                    <Grid2 size={6}>
                        <div style={{ width: '600px', height: '200px', alignItems: "center" }}>
                            <BusinessMap names={[name]} latitudes={[latitude]} longitudes={[longitude]} zoom={zoom} />
                        </div>
                    </Grid2>
                </Grid2>
            </CardContent>
        </Card >
    );
}

export default BusinessInfo;
