import { Box } from '@mui/material';
import Stack from '@mui/material/Stack';
import * as React from 'react';
import Button from '@mui/material/Button';
import Rating from '@mui/material/Rating';
import { useNavigate } from 'react-router-dom';
// const config = require('../config.json');

export default function Results({ city, state, id, name, rating, address, img_val, category, city_code, state_long }) {
    const navigate = useNavigate();

    var route = '/business/';

    if (category === 'Hotels') {
        route = `/hotel/${city_code}/`
    }

    return (

        <Box
            key={id}
            p={2}
            m={2}
            style={{
                background: '#fbf8ee',
                borderRadius: '16px',
                border: '2px solid #f9f6e8',
                display: 'flex'
            }}
        >
            <img
                src={img_val}
                alt="Food"
            />
            <div style={{ textAlign: 'left', marginLeft: '15px' }}>
                <h4 style={{
                    fontSize: '25px',
                    margin: '0',
                }}>
                    {name}
                </h4>

                <h5 style={{
                    fontSize: '15px',
                    color: '#555'
                }}>
                    Ratings: <Rating name="read-only" value={rating} readOnly />
                </h5>
                <h5 style={{
                    fontSize: '15px',
                    color: '#555'
                }}>
                    {address}<br />
                    City: {city}, State: {state}
                </h5>

                <Stack spacing={2} direction="row">
                    <Button variant="contained" onClick={() => {
                        navigate(`${route}${id}?rating=${rating}`)
                        window.location.reload();
                    }}>Select</Button>
                </Stack>
            </div>
        </Box>

    );
}
