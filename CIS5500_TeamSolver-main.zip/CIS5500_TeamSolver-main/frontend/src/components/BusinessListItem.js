import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import BusinessIcon from '@mui/icons-material/Business';
import ListItemButton from '@mui/material/ListItemButton';
import Rating from '@mui/material/Rating';
import { useNavigate } from 'react-router-dom';




const BusinessListItem = ({ business, category }) => {
    var route = '/business/';
    var num_ratings = business.num_ratings;
    var distance = business.distance;
    if (category === "Hotels") {
        num_ratings = 0;
        route = `/hotel/${business.citycode}/`

    }
    // console.log(`bid:${business.id}`)
    const navigate = useNavigate();
    const handleClick = () => {
        window.location.href = `${route}${business.id}?rating=${business.rating}`;
    };

    var secondaryString = `Reviews: ${num_ratings}`
    if (business.distance) { secondaryString = `Reviews: ${num_ratings} just ${distance.toFixed(2)} miles away` }
    return (

        < ListItemButton
            selected={false}
            onClick={handleClick}
            key={business.id}
        >
            <ListItem key={business.id}>
                <ListItemIcon>
                    <BusinessIcon />
                </ListItemIcon>
                <ListItemText
                    primary={business.name}
                    secondary={secondaryString}
                />
                <Rating name="read-only" value={parseInt(business.rating)} readOnly />
            </ListItem>
        </ListItemButton >
    );
};

export default BusinessListItem;