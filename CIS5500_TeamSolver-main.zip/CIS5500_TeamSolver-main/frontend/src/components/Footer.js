import React from 'react';
import { Box, Typography, Link } from '@mui/material';

const Footer = () => {
    return (
        <Box sx={{ bgcolor: 'primary.main', color: 'white', p: 3, mt: 'auto', textAlign: 'center' }}>
            <Typography variant="body1">
                &copy; {new Date().getFullYear()} TeamSolver. All rights reserved.
            </Typography>
            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 1 }}>
                <Link href="#" color="inherit" sx={{ mx: 1 }}>
                    Privacy Policy
                </Link>
                <Link href="#" color="inherit" sx={{ mx: 1 }}>
                    Terms of Service
                </Link>
                <Link href="#" color="inherit" sx={{ mx: 1 }}>
                    Contact Us
                </Link>
            </Box>
        </Box>
    );
};

export default Footer;
