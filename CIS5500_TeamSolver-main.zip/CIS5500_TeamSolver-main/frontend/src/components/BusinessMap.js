import React from 'react';
import Plot from 'react-plotly.js';

const BusinessMap = ({ names, latitudes, longitudes, zoom }) => {
    // console.log(`latitude[0]:${latitudes[0]}, longitude[0]:${longitudes[0]}`)


    var data = [{
        type: 'scattermap',
        text: names,
        locationmode: 'USA-states',
        lon: longitudes,
        lat: latitudes,
        mode: 'markers',
        marker: {
            size: 14
        },
    }]
    // latitude: 40.7128, longitude: -74.0060 }
    var layout = {
        autosize: true,
        hovermode: 'closest',
        map: {
            bearing: 0,
            center: {
                lat: latitudes[0],
                lon: longitudes[0]
            },
            // style: 'open-street-map',
            pitch: 0,
            zoom: zoom
        },
        margin: {
            t: 0,
            b: 0
        }
    }

    const config = {
        displayModeBar: false, // Disables the modebar 
    };

    // const data = [
    //     {
    //         type: 'scattermap',
    //         lat: [40.7128, 34.0522, 41.8781],
    //         lon: [-74.0060, -118.2437, -87.6298],
    //         mode: 'markers',
    //         marker: {
    //             size: 10,
    //             color: 'red'
    //         }
    //     }
    // ];

    // const layout = {
    //     geo: {
    //         scope: 'usa',
    //         projection: { type: 'albers usa' },
    //         showland: true,
    //         landcolor: 'rgb(250, 250, 250)',
    //         subunitcolor: 'rgb(217, 217, 217)',
    //         countrycolor: 'rgb(217, 217, 217)',
    //         countrywidth: 0.5,
    //         subunitwidth: 0.5
    //     }
    // };

    return (
        <Plot
            data={data}
            layout={layout}
            useResizeHandler={true}
            style={{ width: "100%", height: "100%" }}
            config={config}
        />
    );
}

export default BusinessMap;
