CREATE INDEX idx_businesses_city_state ON Businesses (city, state);
CREATE INDEX idx_isCategory_category ON isCategory (category);
CREATE INDEX idx_businesses_name ON Businesses (name);
CREATE INDEX idx_reviews_business_id ON reviews(business_id);

CREATE INDEX idx_businesses_city_state_business_id
ON Businesses (city, state, business_id)
INCLUDE (name, address);

CREATE INDEX idx_iscategory_business_id_category
ON isCategory(business_id, category);

CREATE INDEX idx_reviews_business_id_stars ON reviews(business_id, stars);

CREATE INDEX idx_iscategory_business_id_category ON isCategory(business_id, category);
