**1. Query: Top N Hotels with Highest Average Rating of Nearby Restaurants in a City**

*Description:*
Find the top `:top_n` hotels in a specific city `:city` that have the highest average rating of nearby restaurants within a specified radius `:radius` miles. The distance between the hotel and the restaurant is computed using their latitude and longitude.

*SQL Query:*
```
SELECT 
    h.hotelcode, 
    h.hotelname, 
    AVG(r.stars) AS avg_nearby_restaurant_rating
FROM 
    Hotels h
JOIN 
    Businesses b ON b.city = h.city
JOIN 
    isCategory ic ON b.business_id = ic.business_id
JOIN 
    Categories c ON ic.category_id = c.category_id
JOIN 
    Reviews r ON b.business_id = r.business_id
WHERE 
    h.city = :city AND 
    c.category = 'Restaurants' AND
    (3959 * ACOS(
        COS(RADIANS(h.latitude)) * COS(RADIANS(b.latitude)) * 
        COS(RADIANS(b.longitude) - RADIANS(h.longitude)) + 
        SIN(RADIANS(h.latitude)) * SIN(RADIANS(b.latitude))
    )) <= :radius
GROUP BY 
    h.hotelcode, h.hotelname
ORDER BY 
    avg_nearby_restaurant_rating DESC
LIMIT :top_n;
```
*Placeholders:*
- `:city` (e.g., 'New York')
- `:radius` (e.g., 1.0)
- `:top_n` (e.g., 5)

---

**2. Query: Nearby Businesses Matching User Preferences**

*Description:*
For a given hotel `:hotelcode`, list nearby businesses within a specified radius `:radius` miles that match user-selected categories `:categories` and have an average rating above a certain threshold `:min_rating`.

*SQL Query:*
```
SELECT 
    b.business_id, 
    b.name AS business_name, 
    AVG(r.stars) AS avg_rating
FROM 
    Hotels h
JOIN 
    Businesses b ON 1=1
JOIN 
    isCategory ic ON b.business_id = ic.business_id
JOIN 
    Reviews r ON b.business_id = r.business_id
WHERE 
    h.hotelcode = :hotelcode AND 
    ic.category IN (:categories) AND
    (3959 * ACOS(
        COS(RADIANS(h.latitude)) * COS(RADIANS(b.latitude)) * 
        COS(RADIANS(b.longitude) - RADIANS(h.longitude)) + 
        SIN(RADIANS(h.latitude)) * SIN(RADIANS(b.latitude))
    )) <= :radius
GROUP BY 
    b.business_id, b.name
HAVING 
    AVG(r.stars) >= :min_rating
ORDER BY 
    avg_rating DESC;
```
*Placeholders:*
- `:hotelcode` (e.g., 123)
- `:radius` (e.g., 2.0)
- `:categories` (e.g., 'Italian', 'Mexican')
- `:min_rating` (e.g., 4.0)

---

**3. Query: Hotels Near Businesses with the Most Reviews**

*Description:*
Find hotels that are within a specified radius `:radius` miles of the business with the highest number of reviews in a given city `:city`.

*SQL Query:*
```
WITH top_business AS (
    SELECT 
        b.business_id, 
        b.latitude AS b_latitude, 
        b.longitude AS b_longitude
    FROM 
        Businesses b
    JOIN 
        Reviews r ON b.business_id = r.business_id
    WHERE 
        b.city = :city
    GROUP BY 
        b.business_id, b.latitude, b.longitude
    ORDER BY 
        COUNT(r.review_id) DESC
    LIMIT 1
)
SELECT 
    h.hotelcode, 
    h.hotelname,
    (3959 * ACOS(
        COS(RADIANS(h.latitude)) * COS(RADIANS(tb.b_latitude)) * 
        COS(RADIANS(tb.b_longitude) - RADIANS(h.longitude)) + 
        SIN(RADIANS(h.latitude)) * SIN(RADIANS(tb.b_latitude))
    )) AS distance
FROM 
    Hotels h
CROSS JOIN 
    top_business tb
WHERE 
    (3959 * ACOS(
        COS(RADIANS(h.latitude)) * COS(RADIANS(tb.b_latitude)) * 
        COS(RADIANS(tb.b_longitude) - RADIANS(h.longitude)) + 
        SIN(RADIANS(h.latitude)) * SIN(RADIANS(tb.b_latitude))
    )) <= :radius;
```
*Placeholders:*
- `:city` (e.g., 'San Francisco')
- `:radius` (e.g., 2.0)

---

**4. Query: Hotels Closest to the Highest Rated Business in a Category**

*Description:*
Find the hotel that is closest to the highest-rated business in a specific category `:category`.

*SQL Query:*
```
WITH top_business AS (
    SELECT 
        b.business_id, 
        b.latitude AS b_latitude, 
        b.longitude AS b_longitude
    FROM 
        Businesses b
    JOIN 
        isCategory ic ON b.business_id = ic.business_id
    JOIN 
        Reviews r ON b.business_id = r.business_id
    WHERE 
        ic.category = :category
    GROUP BY 
        b.business_id, b.latitude, b.longitude
    ORDER BY 
        AVG(r.stars) DESC
    LIMIT 1
)
SELECT 
    h.hotelcode, 
    h.hotelname,
    (3959 * ACOS(
        COS(RADIANS(h.latitude)) * COS(RADIANS(tb.b_latitude)) * 
        COS(RADIANS(tb.b_longitude) - RADIANS(h.longitude)) + 
        SIN(RADIANS(h.latitude)) * SIN(RADIANS(tb.b_latitude))
    )) AS distance
FROM 
    Hotels h
CROSS JOIN 
    top_business tb
ORDER BY 
    distance ASC
LIMIT 1;
```
*Placeholders:*
- `:category` (e.g., 'Museums')

---

**5. Query: Hotels Near Highly Rated Businesses in User-Preferred Categories**

*Description:*
Find hotels that are near businesses in user-preferred categories `:categories` with an average rating above a specified threshold `:min_rating`, within a radius `:radius` miles.

*SQL Query:*
```
SELECT DISTINCT 
    h.hotelcode, 
    h.hotelname
FROM 
    Hotels h
JOIN 
    Businesses b ON 1=1
JOIN 
    isCategory ic ON b.business_id = ic.business_id
JOIN 
    Reviews r ON b.business_id = r.business_id
WHERE 
    ic.category IN (:categories) AND
    (3959 * ACOS(
        COS(RADIANS(h.latitude)) * COS(RADIANS(b.latitude)) * 
        COS(RADIANS(b.longitude) - RADIANS(h.longitude)) + 
        SIN(RADIANS(h.latitude)) * SIN(RADIANS(b.latitude))
    )) <= :radius
GROUP BY 
    h.hotelcode, h.hotelname, b.business_id
HAVING 
    AVG(r.stars) >= :min_rating;
```
*Placeholders:*
- `:categories` (e.g., 'Spa', 'Museum')
- `:min_rating` (e.g., 4.5)
- `:radius` (e.g., 1.0)

---

**6. Query: Generate a Customized Itinerary Based on User Interests**

*Description:*
Given a hotel `:hotelcode` and user-selected categories `:categories`, suggest a list of nearby businesses in those categories, ordered by proximity and rating.

*SQL Query:*
```
SELECT 
    b.business_id, 
    b.name AS business_name, 
    (3959 * ACOS(
        COS(RADIANS(h.latitude)) * COS(RADIANS(b.latitude)) * 
        COS(RADIANS(b.longitude) - RADIANS(h.longitude)) + 
        SIN(RADIANS(h.latitude)) * SIN(RADIANS(b.latitude))
    )) AS distance,
    AVG(r.stars) AS avg_rating
FROM 
    Hotels h
JOIN 
    Businesses b ON 1=1
JOIN 
    isCategory ic ON b.business_id = ic.business_id
JOIN 
    Reviews r ON b.business_id = r.business_id
WHERE 
    h.hotelcode = :hotelcode AND 
    ic.category IN (:categories)
GROUP BY 
    b.business_id, b.name, h.latitude, h.longitude, b.latitude, b.longitude
ORDER BY 
    distance ASC, 
    avg_rating DESC;
```
*Placeholders:*
- `:hotelcode` (e.g., 456)
- `:categories` (e.g., 'Art Gallery', 'Historical Site')

---

**7. Query: Hotels with Nearby Businesses Matching All User Criteria**

*Description:*
Find hotels that are near businesses that satisfy all of the following user criteria: specific categories `:categories`, minimum average rating `:min_rating`, and within a specified radius `:radius` miles.

*SQL Query:*
```
SELECT DISTINCT 
    h.hotelcode, 
    h.hotelname
FROM 
    Hotels h
JOIN 
    Businesses b ON 1=1
JOIN 
    isCategory ic ON b.business_id = ic.business_id
JOIN 
    Reviews r ON b.business_id = r.business_id
WHERE 
    ic.category IN (:categories) AND
    (3959 * ACOS(
        COS(RADIANS(h.latitude)) * COS(RADIANS(b.latitude)) * 
        COS(RADIANS(b.longitude) - RADIANS(h.longitude)) + 
        SIN(RADIANS(h.latitude)) * SIN(RADIANS(b.latitude))
    )) <= :radius
GROUP BY 
    h.hotelcode, h.hotelname, b.business_id
HAVING 
    AVG(r.stars) >= :min_rating;
```
*Placeholders:*
- `:radius` (e.g., 1.5)
- `:categories` (e.g., 'Gym', 'Yoga Studio')
- `:min_rating` (e.g., 4.0)

---

**8. Query: Identify Hotels Near Businesses with Exceptional Reviews**

*Description:*
Find hotels that are near businesses where the reviews contain specific keywords `:keyword` (e.g., 'amazing service', 'great ambiance'), within a specified radius `:radius` miles.

*SQL Query:*
```
SELECT DISTINCT 
    h.hotelcode, 
    h.hotelname
FROM 
    Hotels h
JOIN 
    Businesses b ON 1=1
JOIN 
    Reviews r ON b.business_id = r.business_id
WHERE 
    r.text LIKE CONCAT('%', :keyword, '%') AND
    (3959 * ACOS(
        COS(RADIANS(h.latitude)) * COS(RADIANS(b.latitude)) * 
        COS(RADIANS(b.longitude) - RADIANS(h.longitude)) + 
        SIN(RADIANS(h.latitude)) * SIN(RADIANS(b.latitude))
    )) <= :radius;
```
*Placeholders:*
- `:keyword` (e.g., 'amazing service')
- `:radius` (e.g., 1.0)
