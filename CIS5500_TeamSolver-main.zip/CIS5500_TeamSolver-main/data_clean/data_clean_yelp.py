import pandas as pd



# Import JSON module
import json

# Define JSON string

with open('yelp_dataset/yelp_academic_dataset_business.json', 'r', encoding='utf-8') as f:
    d = f.readlines()
    
# jsonString = '{ "id": 121, "name": "Naveen", "course": "MERN Stack"}'

# jsonString = d[0]

# Convert JSON String to Python
business = []

for i in d:
    business.append(json.loads(i))

del d
df = pd.DataFrame(data=business)

df.head()



with open('yelp_dataset/yelp_academic_dataset_review.json', 'r', encoding='utf-8') as f:
    r = f.readlines()

reviews = []
for i in r:
    reviews.append(json.loads(i))

del r

dfr = pd.DataFrame(data=reviews)


dfr.head()    



from haversine import haversine, Unit

# Coordinates of point 1 (latitude, longitude)

point1 = (40.7128, -74.0060)  # New York City



# Coordinates of point 2 (latitude, longitude)

point2 = (34.0522, -118.2437)  # Los Angeles



# Calculate distance in kilometers

distance_km = haversine(point1, point2) 

print("Distance in kilometers:", distance_km)

# Calculate distance in miles

distance_miles = haversine(point1, point2, unit=Unit.MILES) 

print("Distance in miles:", distance_miles) 

#KM
from geopy.distance import geodesic

def calculate_distance(lat1, lon1, lat2, lon2):
    """Calculates the distance in kilometers between two points given their latitude and longitude coordinates."""

    point1 = (lat1, lon1)
    point2 = (lat2, lon2)

    return geodesic(point1, point2).km

# Example usage
lat1, lon1 = 48.8566, 2.3522  # Paris, France
lat2, lon2 = 51.5074, 0.1278  # London, UK

distance = calculate_distance(lat1, lon1, lat2, lon2)
print("Distance:", distance, "km")


"""d.    If you’re not scraping the data: 

relevant size statistics (e.g. 
For a table, 
mb/gb, 
number of rows, 
number of attributes. 

For a graph, mb, number of nodes, and number of edges), and 

summary statistics of 
several attributes (
report mean, standard deviation

A list of at least 5 queries (in natural language) 
you could write for your datasets. 
Some of these should require complex SQL (aggregations, subqueries, joins, etc.)"""