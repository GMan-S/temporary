select *,
       ( 3959 * acos(cos(radians('<input_latitude>')) * cos(radians(latitude)) * cos(radians(longitude) - radians('<input_longitude>'
       )) + sin(radians('<input_latitude>')) * sin(radians(latitude))) ) as distance
  from your_table_name;