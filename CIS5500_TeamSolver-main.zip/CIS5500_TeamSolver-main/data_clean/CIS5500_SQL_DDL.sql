CREATE TABLE Hotels     (
                        hotelcode int,
                        latitude float,
                        longitude float,
                        city varchar(255),
			citycode varchar(255),
                        state varchar(255),
                        zipcode varchar(255),
                        hotelname varchar(255),
                        hotelrating int,
                        address varchar(255),
                        url varchar(255),
                        phoneno varchar(255),
                        description varchar(255),
                        PRIMARY KEY(hotelcode, citycode)
                        );

CREATE TABLE Businesses (
                        business_id varchar(255),
                        name varchar(255),
                        address varchar(255),
                        city varchar(255),
                        state varchar(255),
                        zipcode varchar(255),
                        latitude float,
                        longitude float,
			rating int,
			num_ratings int,
                        PRIMARY KEY(business_id)
                        );


CREATE TABLE Reviews    (
                        review_id varchar(255),
                        business_id varchar(255),
                        stars int,
                        text varchar(255),
                        PRIMARY KEY(review_id),
                        FOREIGN KEY(business_id) REFERENCES Businesses(business_id)
                        );

CREATE TABLE isCategory (
                        business_id varchar(255),
                        category_id varchar(255),
                        category varchar(255),
                        PRIMARY KEY(business_id,category_id),
                        FOREIGN KEY(business_id) REFERENCES Businesses(business_id),
                        FOREIGN KEY(category_id) REFERENCES Categories(category_id)
                        );

CREATE TABLE photos     (
                        photo_id varchar(255),
                        business_id varchar(255) NOT NULL,
                        PRIMARY KEY(photo_id),
                        FOREIGN KEY(business_id) REFERENCES Businesses(business_id)
                        );
                        
