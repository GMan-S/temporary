import pandas as pd

# read in data to dataframe
dfh = pd.read_csv('hotels.csv', encoding='latin-1')

# with open('hotels.csv', 'r') as f:
#     for i in range(100):
#         print(f.readline())

# cleaning column names, making lowecase, removing leading/trailing whitespace
dfh.columns = [i.strip().lower() for i in dfh.columns]

# creating a zipcode column, extracting zipcode from address field
dfh.loc[dfh.countycode=='US', 'zipcode'] = dfh.loc[dfh.countycode=='US'].address.apply(lambda x: str(x)[-6:])

# filtering for US onlu
dfh = dfh.loc[dfh.countycode=='US']

# creating a state column, extracting from citinyame field
dfh['state'] = dfh.cityname.str.split(',',expand=True)[1].str.strip()

# special case for 'Hawaii County
dfh.loc[dfh.state=='Hawaii County', 'state'] = 'Hawaii'

# creating reformatted city field
dfh['city'] = dfh.cityname.str.split(',',expand=True)[0].str.strip()

#
dfh['latitude'] = dfh['map'].str.split('|',expand=True)[0].astype(float)
dfh['longitude'] = dfh['map'].str.split('|',expand=True)[1].astype(float)



#testing calculating distance from 1 lat/lon to ALL hotels 
from haversine import haversine, Unit

# Coordinates of point 1 (latitude, longitude)

point1 = (40.7128, -74.0060)  # New York City

def my_function(row):
    point2 = (row['latitude'],  row['longitude'])
    return haversine(point1, point2, unit=Unit.MILES)
    # return row['latitude'] 

dfh.apply(my_function, axis=1)



# Coordinates of point 2 (latitude, longitude)

point2 = (34.0522, -118.2437)  # Los Angeles



# Calculate distance in kilometers

distance_km = haversine(point1, point2) 

print("Distance in kilometers:", distance_km)

# Calculate distance in miles

distance_miles = haversine(point1, point2, unit=Unit.MILES) 

print("Distance in miles:", distance_miles) 