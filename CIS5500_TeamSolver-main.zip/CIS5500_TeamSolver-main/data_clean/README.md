# CIS5500 TeamSolver Data Cleaning and ETL

This repository contains files and scripts for cleaning, transforming, and loading data as part of the CIS5500 TeamSolver project. The dataset focuses on hotels, businesses, and Yelp reviews. The code also includes SQL scripts for database schema definitions and queries.

---

## Directory Structure
- **CIS5500_SQL_DDL.sql**: SQL script for defining the database schema.
- **Hotels_Businesses_Categories_Data_Clean_ETL.ipynb**: Jupyter Notebook for cleaning and transforming hotel, business, and category data.
- **Reviews_Photos_Data_Clean.ipynb**: Jupyter Notebook for cleaning and processing Yelp reviews and photos data.
- **complex_sql_queries.md**: Documentation containing complex SQL queries.
- **data_clean_hotels.py**: Python script for cleaning and processing hotel data.
- **data_clean_yelp.py**: Python script for cleaning and processing Yelp data.
- **distance.sql**: SQL script for calculating distances between entities in the database.
- **indexes.sql**: SQL script for creating database indexes to optimize query performance.
- **requirements.txt**: Python dependencies required to run the scripts.

---

## Prerequisites
1. **Python**: Install Python 3.8 or later.
2. **Jupyter Notebook**: Ensure Jupyter Notebook is installed to run `.ipynb` files.
3. **PostgreSQL**: Install PostgreSQL for database setup and operations.
4. **Dependencies**: Install the required Python packages using `requirements.txt`:
   ```bash
   pip install -r requirements.txt
## How to Run

1. **Run the Jupyter Notebooks**:
   - Open the provided Jupyter Notebooks (`Hotels_Businesses_Categories_Data_Clean_ETL.ipynb` and `Reviews_Photos_Data_Clean.ipynb`) using Google Colab.
   - Follow the instructions within the notebooks to clean and preprocess the data.
   - Save the cleaned data files locally to your machine.

2. **Import Cleaned Files to PostgreSQL**:
   - Use the saved cleaned files to populate the PostgreSQL tables.
   - Ensure the PostgreSQL schema matches the structure defined in `CIS5500_SQL_DDL.sql`.
   - Import each file into its respective table using your preferred PostgreSQL client or tools such as DataGrip or `psql`.
