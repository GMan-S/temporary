## **README**

# Project Description

Planning travel often requires back and forth between multiple platforms to book hotels and discover local attractions. This kind of tasks can sometimes be timeconsuming and boring. Our web application “Expedia Meets Yelp” solves this issue by combines hotel listings with local business information to make this overall process easier. In our platfiorm, users can easily search for hotels and see nearby businesses including restaurants and other point of attractions in a single platform.

# Frontend

Frontend uses React.js for building user interface. We started off from Homework 3 frontend resources that was provided us. Frontend has 4 different pages

## Setup Instructions

1. **Install Dependencies**

   Install npm:

   ```bash
   npm install
   ```

2. **Run Frontend**

   Run Frontend:
   Navigate to frontend directory firts after that use the command below

   ```bash
   npm start
   ```
## Pages

• Landing Page: User inputs City, State, Categories and Search text here
• Results Page: Afetr user clicks search in Landing page, they are redericted to Results page which consists of results based on the input they selected
• Business Page: Once the user clicks on any of the business page, they are redirected to this page which contains more details about the business
• Hotels Page: Once the user clicks on any of the Hotels from results page, they are redirected to this page which contains more details about the business


# Backend

This is a FastAPI application that interacts with a PostgreSQL database to perform complex SQL queries for a travel itinerary planning application. It allows users to find hotels and nearby businesses based on various criteria.

## Features

- **Search Hotels:** Find top-rated hotels in a city based on nearby restaurant ratings.
- **Nearby Businesses:** List nearby businesses matching user preferences.
- **Custom Itineraries:** Generate itineraries based on user interests.
- **Advanced Queries:** Utilize complex SQL queries for enhanced search capabilities.

## Project Structure

```
project_root/
├── app/
│   ├── main.py
│   ├── core/
│   ├── db/
│   ├── models/
│   ├── schemas/
│   ├── api/
│   ├── tests/
│   └── alembic/
├── pyproject.toml
├── alembic.ini
├── .env
├── .gitignore
├── Dockerfile
├── docker-compose.yml
├── README.md
└── LICENSE
```

## Setup Instructions

### Prerequisites

- **Python 3.9+**
- **Docker and Docker Compose**
- **Poetry** (for dependency management)

### Installation

1. **Clone the Repository**

2. **Set Up Environment Variables**

   The `.env` file in the root directory has database credentials and is ready to go. Feel free to make modification if needed:

   ```ini
   POSTGRES_USER=your_user
   POSTGRES_PASSWORD=your_password
   POSTGRES_SERVER=localhost
   POSTGRES_PORT=5432
   POSTGRES_DB=your_database
   ```

3. **Install Dependencies**

   Install dependencies using Poetry:

   ```bash
   poetry install
   ```

4. **Run Database Migrations**

   Initialize the database and run migrations:

   ```bash
   alembic upgrade head
   ```

### Running the Application

#### Using Docker Compose

1. **Build and Run the Containers**

   ```bash
   docker-compose up --build db web 
   ```

2. **Access the API**

   The API will be available at `http://localhost:8000`.

#### Without Docker

1. **Start the FastAPI Server**

   ```bash
   uvicorn app.main:app --reload
   ```

2. **Access the API**

   The API will be available at `http://127.0.0.1:8000`.

### API Documentation

Interactive API documentation is available at:

- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

### Running Tests

Run unit tests using pytest:

```bash
pytest
```

### Code Formatting and Linting

Ensure code quality using the following tools:

- **Black** (code formatting):

  ```bash
  black app/
  ```

- **isort** (import sorting):

  ```bash
  isort app/
  ```

- **Flake8** (linting):

  ```bash
  flake8 app/
  ```

### Deployment

For production deployment, consider using a WSGI server like Gunicorn with Uvicorn workers. Update the `Dockerfile` and `docker-compose.yml` accordingly.

## Project Details

### Endpoints


1. **Get Business Photos**

   - **URL:** `/api/v1`
   - **Method:** `GET`
   - **Parameters:**
     - `bid`: Business Id

2. **Get Random Hotels**

   - **URL:** `/api/v1/hotels_random`
   - **Method:** `GET`
   - **Parameters:**
     - `city`: The city to search in.
     - `state`: The state to search in
     - `category`: Categories that user selects

3. **Get High Rated Hotels**

   - **URL:** `/api/v1/hotels_high_rated`
   - **Method:** `GET`
   - **Parameters:**
     - `city`: The city to search in.
     - `state`: The state to search in.
     - `category`: Categories that user selects

4. **Get Low rated Hotels**

   - **URL:** `/api/v1/hotels_low_rated`
   - **Method:** `GET`
   - **Parameters:**
     - `city`: The city to search in.
     - `state`: The state to search in.
     - `category`: Categories that user selects


5. **Get Random Business**

   - **URL:** `/api/v1/business_random`
   - **Method:** `GET`
   - **Parameters:**
     - `city`: The city to search in.
     - `state`: The state to search in.
     - `category`: Categories that user selects
     - `stext`: str: Search text

6. **Get High Rated Business**

   - **URL:** `/api/v1/business_high_rated`
   - **Method:** `GET`
   - **Parameters:**
     - `city`: The city to search in.
     - `state`: The state to search in.
     - `category`: Categories that user selects
     - `stext`: str: Search text

7. **Get High Rated Business Optimized**

   - **URL:** `/api/v1/business_high_rated_optimized`
   - **Method:** `GET`
   - **Parameters:**
     - `city`: The city to search in.
     - `state`: The state to search in.
     - `category`: Categories that user selects
     - `stext`: str: Search text

8. **Get Low rated Business**

   - **URL:** `/api/v1/business_low_rated`
   - **Method:** `GET`
   - **Parameters:**
     - `city`: The city to search in.
     - `state`: The state to search in.
     - `category`: Categories that user selects
     - `stext`: str: Search text
       
9. **List of States**

   - **URL:** `/api/v1/states`
   - **Method:** `GET`
   - **Parameters:**
   
10. **List of Cities**

   - **URL:** `/api/v1/cities`
   - **Method:** `GET`
   - **Parameters:**
     - `state`: The state to search in.

11. ** Cities Categories**

   - **URL:** `/api/v1/city-categories`
   - **Method:** `GET`
   - **Parameters:**
     - `city`: The city to search in.
     - `state`: The state to search in.

12. ** Business Names**

   - **URL:** `/api/v1/businesss_names`
   - **Method:** `GET`
   - **Parameters:**
     - `city`: The city to search in.
     - `state`: The state to search in.
     - category`: Categories that user selects    

13. **Get Top Hotels**

   - **URL:** `/api/v1/top_hotels`
   - **Method:** `GET`
   - **Parameters:**
     - `city`: The city to search in.
     - `radius`: The search radius in miles.
     - `top_n`: The number of top hotels to return.

14. **Get Nearby Businesses**

   - **URL:** `/api/v1/nearby_businesses`
   - **Method:** `GET`
   - **Parameters:**
     - `hotelcode`: The hotel code.
     - `radius`: The search radius in miles.
     - `categories`: List of desired business categories.
     - `min_rating`: Minimum average rating.

15. **Hotels Near Popular Business**

   - **URL:** `/api/v1/hotels_near_popular_business`
   - **Method:** `GET`
   - **Parameters:**
     - `city`: The city to search in.
     - `radius`: The search radius in miles.

16. **Closest Hotel to Top Business**

   - **URL:** `/api/v1/closest_hotel_to_top_business`
   - **Method:** `GET`
   - **Parameters:**
     - `category`: Business category.

17. **Closest Hotel to Top Business Optimized**

   - **URL:** `/api/v1/top_business_in_category_optimized`
   - **Method:** `GET`
   - **Parameters:**
     - `category`: Business category.

18. **Hotels Near Highly Rated Businesses**

   - **URL:** `/api/v1/hotels_near_highly_rated_businesses`
   - **Method:** `GET`
   - **Parameters:**
     - `categories`: List of business categories.
     - `min_rating`: Minimum average rating.
     - `radius`: The search radius in miles.
    
19. **Hotels Near Highly Rated Businesses Optimized**

   - **URL:** `/api/v1/hotels_near_highly_rated_businesses_optimized`
   - **Method:** `GET`
   - **Parameters:**
     - `categories`: List of business categories.
     - `min_rating`: Minimum average rating.
     - `radius`: The search radius in miles.

20. **Custom Itinerary**

   - **URL:** `/api/v1/custom_itinerary`
   - **Method:** `GET`
   - **Parameters:**
     - `hotelcode`: The hotel code.
     - `categories`: List of desired business categories.

21. **Hotels with Matching Businesses**

   - **URL:** `/api/v1/hotels_with_matching_businesses`
   - **Method:** `GET`
   - **Parameters:**
     - `radius`: The search radius in miles.
     - `categories`: List of business categories.
     - `min_rating`: Minimum average rating.

22. **Hotels Near Businesses with Reviews**

   - **URL:** `/api/v1/hotels_near_businesses_with_reviews`
   - **Method:** `GET`
   - **Parameters:**
     - `keyword`: Keyword to search in reviews.
     - `radius`: The search radius in miles.
       
23. **Closest Restaurants Near Given Latitude and Longitude with Rating Above Threshold**

   - **URL:** `/api/v1/closest_restaurants`
   - **Method:** `GET`
   - **Parameters:**
     - `keyword`:
     - latitude: float
     - longitude: float
     - radius: float
     - stars: float
     - top_n: int
       
24. **Nearby Restaurants with Average Rating and Number of Reviews Above Thresholds**

   - **URL:** `/api/v1/nearby_restaurants_with_reviews`
   - **Method:** `GET`
   - **Parameters:**
     - `keyword`:
     - latitude: float
     - longitude: float
     - radius: float
     - stars: float
     - num_reviews: int,
    
25. **Fetch Distinct Categories**
    - **URL:** `/api/v1/categories`
    - **Method:** `GET`

   

### Database Schema

The database uses the following tables:

- `hotel`
- `business`
- `review`
- `category`
- `iscategory`
- `photo`

### Models and Schemas

Models are defined using SQLAlchemy ORM in `app/models/`, and Pydantic schemas are defined in `app/schemas/`.

### Alembic Migrations

Database migrations are managed using Alembic. The migration scripts are located in `app/alembic/versions/`.

## Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository.
2. Create a new branch (`git checkout -b feature/your-feature`).
3. Commit your changes (`git commit -m 'Add your feature'`).
4. Push to the branch (`git push origin feature/your-feature`).
5. Open a pull request.


**Note:** Replace placeholders like `your_user`, `your_password`, `your_database`, `your_username`, and `you@example.com` with your actual information.
