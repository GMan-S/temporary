# app/models/__init__.py

from .hotel import HotelBase
from .business import BusinessBase
from .review import ReviewBase
from .category import CategoryBase
from .is_category import IsCategoryBase
from .photo import PhotoBase
