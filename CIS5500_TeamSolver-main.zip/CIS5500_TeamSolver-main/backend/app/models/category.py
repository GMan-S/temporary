# app/schemas/category.py

from pydantic import BaseModel


class CategoryBase(BaseModel):
    category_id: str
    category: str

    class Config:
        orm_mode = True
