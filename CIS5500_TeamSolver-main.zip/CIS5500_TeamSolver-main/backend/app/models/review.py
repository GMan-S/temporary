# app/schemas/review.py

from pydantic import BaseModel


class ReviewBase(BaseModel):
    review_id: str
    business_id: str
    stars: int
    text: str

    class Config:
        orm_mode = True
