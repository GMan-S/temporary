# app/schemas/photo.py

from pydantic import BaseModel


class PhotoBase(BaseModel):
    photo_id: str
    business_id: str

    class Config:
        orm_mode = True
