# app/models/hotel.py

from pydantic import BaseModel


class HotelBase(BaseModel):
    hotelcode: int
    latitude: float
    longitude: float
    city: str
    state: str
    zipcode: str
    hotelname: str

    class Config:
        orm_mode = True
