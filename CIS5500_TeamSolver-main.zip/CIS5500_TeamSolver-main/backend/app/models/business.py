# app/schemas/business.py

from pydantic import BaseModel


class BusinessBase(BaseModel):
    business_id: str
    name: str
    address: str
    city: str
    state: str
    zipcode: str
    latitude: float
    longitude: float

    class Config:
        orm_mode = True
