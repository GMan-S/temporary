# app/schemas/is_category.py

from pydantic import BaseModel


class IsCategoryBase(BaseModel):
    business_id: str
    category_id: str
    category: str

    class Config:
        orm_mode = True
