# tests/test_api/test_queries.py

import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import pytest
import asyncio
from httpx import AsyncClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.main import app
from app.core.config import settings
from app.db.base import Base
from app.schemas.hotel import Hotel
from app.schemas.business import Business
from app.schemas.review import Review
from app.schemas.category import Category
from app.schemas.is_category import IsCategory

# Use the test database URL
TEST_DATABASE_URL = f"{settings.DATABASE_URL}"

# Create a new database session for testing
engine = create_engine(TEST_DATABASE_URL)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


@pytest.fixture(scope="module")
def event_loop():
    loop = asyncio.get_event_loop()
    yield loop


@pytest.fixture(scope="module")
def test_app():
    # Create the database tables
    Base.metadata.create_all(bind=engine)
    yield app
    # Drop the database tables after tests
    Base.metadata.drop_all(bind=engine)


@pytest.fixture(scope="module")
async def client(test_app):
    async with AsyncClient(app=test_app, base_url="http://test") as ac:
        yield ac


# Helper function to insert test data
def insert_test_data(db_session):
    # Insert test hotels
    hotel1 = Hotel(
        hotelcode=1,
        latitude=40.7128,
        longitude=-74.0060,
        city="Test City",
        state="Test State",
        zipcode="10001",
        hotelname="Test Hotel 1"
    )
    hotel2 = Hotel(
        hotelcode=2,
        latitude=40.730610,
        longitude=-73.935242,
        city="Test City",
        state="Test State",
        zipcode="10002",
        hotelname="Test Hotel 2"
    )
    db_session.add_all([hotel1, hotel2])
    db_session.commit()

    # Insert test businesses
    business1 = Business(
        business_id="b1",
        name="Test Restaurant 1",
        address="123 Test St",
        city="Test City",
        state="Test State",
        zipcode="10001",
        latitude=40.7138,
        longitude=-74.0050
    )
    business2 = Business(
        business_id="b2",
        name="Test Museum",
        address="456 Test Ave",
        city="Test City",
        state="Test State",
        zipcode="10001",
        latitude=40.7148,
        longitude=-74.0040
    )
    business3 = Business(
        business_id="b3",
        name="Test Spa",
        address="789 Test Blvd",
        city="Test City",
        state="Test State",
        zipcode="10001",
        latitude=40.7158,
        longitude=-74.0030
    )
    db_session.add_all([business1, business2, business3])
    db_session.commit()

    # Insert test categories
    category_restaurant = Category(
        category_id="c1",
        category="Restaurants"
    )
    category_museum = Category(
        category_id="c2",
        category="Museums"
    )
    category_spa = Category(
        category_id="c3",
        category="Spa"
    )
    db_session.add_all([category_restaurant, category_museum, category_spa])
    db_session.commit()

    # Associate businesses with categories (is_category)
    is_category1 = IsCategory(
        business_id="b1",
        category_id="c1",
        category="Restaurants"
    )
    is_category2 = IsCategory(
        business_id="b2",
        category_id="c2",
        category="Museums"
    )
    is_category3 = IsCategory(
        business_id="b3",
        category_id="c3",
        category="Spa"
    )
    db_session.add_all([is_category1, is_category2, is_category3])
    db_session.commit()

    # Insert test reviews
    review1 = Review(
        review_id="r1",
        business_id="b1",
        stars=5.0,
        text="Amazing food and service!"
    )
    review2 = Review(
        review_id="r2",
        business_id="b2",
        stars=4.0,
        text="Great exhibits and friendly staff."
    )
    review3 = Review(
        review_id="r3",
        business_id="b3",
        stars=5.0,  # Adjusted to 5.0 to meet min_rating criteria
        text="Relaxing but could be better."
    )
    db_session.add_all([review1, review2, review3])
    db_session.commit()


@pytest.fixture(scope="module")
def db_session():
    connection = engine.connect()
    transaction = connection.begin()
    session = TestingSessionLocal(bind=connection)
    insert_test_data(session)
    yield session
    session.close()
    transaction.rollback()
    connection.close()


@pytest.mark.asyncio
async def test_get_top_hotels(client, db_session):
    response = await client.get("/api/v1/top_hotels", params={"city": "Test City", "radius": 5000, "top_n": 5})
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    # Uncomment the line below for debugging if needed
    print("Response data:", data)
    assert len(data) > 0


# @pytest.mark.asyncio
# async def test_get_nearby_businesses(client, db_session):
#     params = [
#         ('hotelcode', '1'),
#         ('radius', '5.0'),
#         ('categories', 'Restaurants'),
#         ('min_rating', '4.0')
#     ]
#     response = await client.get("/api/v1/nearby_businesses", params=params)
#     assert response.status_code == 200
#     data = response.json()
#     assert isinstance(data, list)
#     # Uncomment the line below for debugging if needed
#     # print("Response data:", data)
#     assert len(data) > 0
#
#
# @pytest.mark.asyncio
# async def test_hotels_near_popular_business(client, db_session):
#     response = await client.get(
#         "/api/v1/hotels_near_popular_business",
#         params={"city": "Test City", "radius": '5.0'}
#     )
#     assert response.status_code == 200
#     data = response.json()
#     assert isinstance(data, list)
#     # Uncomment the line below for debugging if needed
#     # print("Response data:", data)
#     assert len(data) > 0
#
#
# @pytest.mark.asyncio
# async def test_closest_hotel_to_top_business(client, db_session):
#     response = await client.get(
#         "/api/v1/closest_hotel_to_top_business",
#         params={"category": "Museums"}
#     )
#     assert response.status_code == 200 or response.status_code == 404
#     if response.status_code == 200:
#         data = response.json()
#         assert isinstance(data, dict)
#         # Uncomment the line below for debugging if needed
#         # print("Response data:", data)
#
#
# @pytest.mark.asyncio
# async def test_hotels_near_highly_rated_businesses(client, db_session):
#     params = [
#         ('categories', 'Spa'),
#         ('categories', 'Museums'),
#         ('min_rating', '4.0'),
#         ('radius', '5.0')
#     ]
#     response = await client.get("/api/v1/hotels_near_highly_rated_businesses", params=params)
#     assert response.status_code == 200
#     data = response.json()
#     assert isinstance(data, list)
#     # Uncomment the line below for debugging if needed
#     # print("Response data:", data)
#     assert len(data) > 0
#
#
# @pytest.mark.asyncio
# async def test_custom_itinerary(client, db_session):
#     params = [
#         ('hotelcode', '1'),
#         ('categories', 'Museums'),
#         ('categories', 'Spa')
#     ]
#     response = await client.get("/api/v1/custom_itinerary", params=params)
#     assert response.status_code == 200
#     data = response.json()
#     assert isinstance(data, list)
#     # Uncomment the line below for debugging if needed
#     # print("Response data:", data)
#     assert len(data) > 0
#
#
# @pytest.mark.asyncio
# async def test_hotels_with_matching_businesses(client, db_session):
#     params = [
#         ('radius', '5.0'),
#         ('categories', 'Restaurants'),
#         ('min_rating', '4.0')
#     ]
#     response = await client.get("/api/v1/hotels_with_matching_businesses", params=params)
#     assert response.status_code == 200
#     data = response.json()
#     assert isinstance(data, list)
#     # Uncomment the line below for debugging if needed
#     # print("Response data:", data)
#     assert len(data) > 0
#
#
# @pytest.mark.asyncio
# async def test_hotels_near_businesses_with_reviews(client, db_session):
#     response = await client.get(
#         "/api/v1/hotels_near_businesses_with_reviews",
#         params={
#             "keyword": "amazing",
#             "radius": '5.0'
#         }
#     )
#     assert response.status_code == 200
#     data = response.json()
#     assert isinstance(data, list)
#     # Uncomment the line below for debugging if needed
#     # print("Response data:", data)
#     assert len(data) > 0
