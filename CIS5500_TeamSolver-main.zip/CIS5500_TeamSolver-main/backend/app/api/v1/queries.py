# app/api/v1/queries.py

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response, HTMLResponse, JSONResponse
from sqlalchemy.orm import Session
from typing import List
from app import schemas, models
from app.api import deps
from sqlalchemy.sql import text

router = APIRouter()

state_abbreviations = {
    "AL": "Alabama",
    "AK": "Alaska",
    "AZ": "Arizona",
    "AR": "Arkansas",
    "CA": "California",
    "CO": "Colorado",
    "CT": "Connecticut",
    "DE": "Delaware",
    "FL": "Florida",
    "GA": "Georgia",
    "HI": "Hawaii",
    "ID": "Idaho",
    "IL": "Illinois",
    "IN": "Indiana",
    "IA": "Iowa",
    "KS": "Kansas",
    "KY": "Kentucky",
    "LA": "Louisiana",
    "ME": "Maine",
    "MD": "Maryland",
    "MA": "Massachusetts",
    "MI": "Michigan",
    "MN": "Minnesota",
    "MS": "Mississippi",
    "MO": "Missouri",
    "MT": "Montana",
    "NE": "Nebraska",
    "NV": "Nevada",
    "NH": "New Hampshire",
    "NJ": "New Jersey",
    "NM": "New Mexico",
    "NY": "New York",
    "NC": "North Carolina",
    "ND": "North Dakota",
    "OH": "Ohio",
    "OK": "Oklahoma",
    "OR": "Oregon",
    "PA": "Pennsylvania",
    "RI": "Rhode Island",
    "SC": "South Carolina",
    "SD": "South Dakota",
    "TN": "Tennessee",
    "TX": "Texas",
    "UT": "Utah",
    "VT": "Vermont",
    "VA": "Virginia",
    "WA": "Washington",
    "WV": "West Virginia",
    "WI": "Wisconsin",
    "WY": "Wyoming"
}


# Existing endpoint for Query 1
@router.get("/business-info")
def photos(bid: str, db: Session = Depends(deps.get_db)):
    """Returns the list of photo identifiers belonging to the business with business id

    Args:
        bid (str): a business id
        db (Session, optional): a sqlalchemy Session object. Defaults to Depends(deps.get_db).

    Returns:
        [JSON]: an array of JSON objects (e.g. [{'state':'CA', 'state_desc':'California'}])
    """
    sql_query = text(f"""
    select b.*
    from businesses b
    where b.business_id = '{bid}'
    """)
    result = db.execute(sql_query)
    result_dict = [dict(row) for row in result]

    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict[0], status_code=200, headers=headers)


@router.get("/hotel-info")
def photos(hcode: str, ccode: str, db: Session = Depends(deps.get_db)):
    """Returns the list of photo identifiers belonging to the business with business id

    Args:
        hcode (str): a hotel code
        ccode (str): a city code
        db (Session, optional): a sqlalchemy Session object. Defaults to Depends(deps.get_db).

    Returns:
        [JSON]: an array of JSON objects (e.g. [{'state':'CA', 'state_desc':'California'}])
    """
    sql_query = text(f"""
    select * 
    from hotels
    where hotelcode = '{hcode}'
    and citycode = '{ccode}'
    """)
    result = db.execute(sql_query)
    result_dict = [dict(row) for row in result]

    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict[0], status_code=200, headers=headers)


@router.get("/photos")
def photos(bid: str, db: Session = Depends(deps.get_db)):
    """Returns the list of photo identifiers belonging to the business with business id

    Args:
        bid (str): a business id
        db (Session, optional): a sqlalchemy Session object. Defaults to Depends(deps.get_db).

    Returns:
        [JSON]: an array of JSON objects (e.g. [{'state':'CA', 'state_desc':'California'}])
    """
    sql_query = text(f"""
    select * 
    from photos 
    where business_id = '{bid}'
    order by photo_id
    """)
    result = db.execute(sql_query)
    result_dict = [dict(row) for row in result]

    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


@router.get("/business_high_rated_in_city")
def get_business_high_rated_in_city(
        city: str,
        state: str,
        db: Session = Depends(deps.get_db)
):
    sql = text("""
    SELECT
        b.business_id AS id,
        b.name AS name,
        b.rating,
        b.num_ratings,               
        b.address AS address
    FROM
        businesses b
    WHERE
        b.city = :city AND
        b.state = :state
    ORDER BY
        rating DESC, num_ratings DESC
    LIMIT 10;
    """)

    params = {"city": city, "state": state}
    result = db.execute(sql, params)
    result_dict = [dict(row) for row in result]
    # print(result_dict)
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


@router.get("/hotels_random")
def get_random_hotels(
        city: str,
        state_long: str,
        category: str,
        stext: str = '',
        db: Session = Depends(deps.get_db)
):
    def count_word_matches(name, words):
        name_words = name.lower().split()
        return sum(word in name_words for word in words)

    def sort_dicts_by_name_matches(dicts, words):
        return sorted(dicts, key=lambda d: count_word_matches(d['name'], words), reverse=True)

    # Example usage

    stext_list = stext.lower().split()

    text_search = "".join([f"""OR lower(h.hotelname) LIKE '%{word}%'
        """ for word in stext_list])

    sql_query = text(f"""
    SELECT
        h.hotelcode AS id,
        h.hotelname AS name,
        h.hotelrating AS rating,
        h.address AS address,
        h.citycode
    FROM
        hotels h
    WHERE
        h.city = :city AND
        h.state = :state AND
        (lower(h.hotelname) LIKE '%{stext.lower()}%'
        {text_search})
    LIMIT 200;
    """)
    result = db.execute(sql_query, {"city": city, "state": state_long})
    result_dict = [dict(row) for row in result]
    result_dict = sort_dicts_by_name_matches(result_dict, stext_list)
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


@router.get("/hotels_high_rated")
def get_hotels_high_rated(
        city: str,
        state_long: str,
        category: str,
        stext: str = '',
        db: Session = Depends(deps.get_db)
):
    def count_word_matches(name, words):
        name_words = name.lower().split()
        return sum(word in name_words for word in words)

    def sort_dicts_by_name_matches(dicts, words):
        return sorted(dicts, key=lambda d: count_word_matches(d['name'], words), reverse=True)

    # Example usage

    stext_list = stext.lower().split()

    text_search = "".join([f"""OR lower(h.hotelname) LIKE '%{word}%'
        """ for word in stext_list])

    sql_query = text(f"""
    SELECT
        h.hotelcode AS id,
        h.hotelname AS name,
        h.hotelrating AS rating,
        h.address AS address,
        h.citycode
    FROM
        hotels h
    WHERE
        h.city = :city AND
        h.state = :state AND
        (lower(h.hotelname) LIKE '%{stext.lower()}%'
        {text_search})
    ORDER BY rating DESC
    LIMIT 200;
    """)
    result = db.execute(sql_query, {"city": city, "state": state_long})
    result_dict = [dict(row) for row in result]
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


@router.get("/hotels_low_rated")
def get_hotels_low_rated(
        city: str,
        state_long: str,
        category: str,
        stext: str = '',
        db: Session = Depends(deps.get_db)
):
    def count_word_matches(name, words):
        name_words = name.lower().split()
        return sum(word in name_words for word in words)

    def sort_dicts_by_name_matches(dicts, words):
        return sorted(dicts, key=lambda d: count_word_matches(d['name'], words), reverse=True)

    # Example usage

    stext_list = stext.lower().split()

    text_search = "".join([f"""OR lower(h.hotelname) LIKE '%{word}%'
        """ for word in stext_list])

    sql_query = text(f"""
    SELECT
        h.hotelcode AS id,
        h.hotelname AS name,
        h.hotelrating AS rating,
        h.address AS address,
        h.citycode
    FROM
        hotels h
    WHERE
        h.city = :city AND
        h.state = :state AND
        (lower(h.hotelname) LIKE '%{stext.lower()}%'
        {text_search})
    ORDER BY rating
    LIMIT 200;
    """)
    result = db.execute(sql_query, {"city": city, "state": state_long})
    result_dict = [dict(row) for row in result]
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


@router.get("/business_random")
def get_random_business(
        city: str,
        state: str,
        category: str,
        stext: str = '',
        db: Session = Depends(deps.get_db)
):
    def count_word_matches(name, words):
        name_words = name.lower().split()
        return sum(word in name_words for word in words)

    def sort_dicts_by_name_matches(dicts, words):
        return sorted(dicts, key=lambda d: count_word_matches(d['name'], words), reverse=True)

    # Example usage

    stext_list = stext.lower().split()

    text_search = "".join([f"""OR lower(b.name) LIKE '%{word}%'
        """ for word in stext_list])

    sql = f"""
    SELECT
        b.business_id AS id,
        b.name AS name,
        b.rating,
        b.num_ratings,
        b.address AS address,
        ic.category
    FROM
        businesses b
    JOIN
        iscategory ic ON b.business_id = ic.business_id
    WHERE
        b.city = '{city}' AND
        b.state = '{state}' AND
        ic.category = '{category.replace("'","''")}' AND
        (lower(b.name) LIKE '%{stext.lower()}%'
        {text_search})
    LIMIT 200;
    """

    sql_query = text(sql)

    result = db.execute(sql_query, {"city": city, "state": state, "category": category})
    result_dict = [dict(row) for row in result]
    result_dict = sort_dicts_by_name_matches(result_dict, stext_list)
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


@router.get("/business_high_rated")
def get_business_high_rated(
        city: str,
        state: str,
        category: str,
        stext: str = '',
        db: Session = Depends(deps.get_db)
):
    def count_word_matches(name, words):
        name_words = name.lower().split()
        return sum(word in name_words for word in words)

    def sort_dicts_by_name_matches(dicts, words):
        return sorted(dicts, key=lambda d: count_word_matches(d['name'], words), reverse=True)

    # Example usage

    stext_list = stext.lower().split()

    text_search = "".join([f"""OR lower(b.name) LIKE '%{word}%'
        """ for word in stext_list])

    sql = f"""
    SELECT
        b.business_id AS id,
        b.name AS name,
        b.rating,
        b.num_ratings,
        b.address AS address,
        ic.category
    FROM
        businesses b
    JOIN
        iscategory ic ON b.business_id = ic.business_id
    WHERE
        b.city = '{city}' AND
        b.state = '{state}' AND
        ic.category = '{category.replace("'","''")}' AND
        (lower(b.name) LIKE '%{stext.lower()}%'
        {text_search})
    ORDER BY
        b.rating DESC
    LIMIT 200;
    """

    sql_query = text(sql)

    # print('split text',stext.split())
    print(sql)
    result = db.execute(sql_query, {"city": city, "state": state, "category": category})
    result_dict = [dict(row) for row in result]
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


@router.get("/business_high_rated_optimized")
def get_business_high_rated_optimized(
        city: str,
        state: str,
        category: str,
        stext: str = '',
        db: Session = Depends(deps.get_db)
):
    sql = """
    SELECT
        b.business_id AS id,
        b.name AS name,
        COALESCE(ROUND(AVG(r.stars), 1), 0) AS rating,
        b.address AS address
    FROM
        Businesses b
    JOIN
        isCategory ic ON b.business_id = ic.business_id
    LEFT JOIN
        Reviews r ON b.business_id = r.business_id
    WHERE
        b.city = :city AND
        b.state = :state AND
        ic.category = :category AND
        b.name ILIKE '%' || :stext || '%'
    ORDER BY
        rating DESC
    LIMIT 200;
    """

    sql_query = text(sql)
    result = db.execute(sql_query, {
        "city": city,
        "state": state,
        "category": category,
        "stext": stext
    })
    result_dict = [dict(row) for row in result]
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


@router.get("/business_low_rated")
def get_business_low_rated(
        city: str,
        state: str,
        category: str,
        stext: str = '',
        db: Session = Depends(deps.get_db)
):
    def count_word_matches(name, words):
        name_words = name.lower().split()
        return sum(word in name_words for word in words)

    def sort_dicts_by_name_matches(dicts, words):
        return sorted(dicts, key=lambda d: count_word_matches(d['name'], words), reverse=True)

    # Example usage

    stext_list = stext.lower().split()

    text_search = "".join([f"""OR lower(b.name) LIKE '%{word}%'
        """ for word in stext_list])

    sql = f"""
    SELECT
        b.business_id AS id,
        b.name AS name,
        b.rating,
        b.num_ratings,
        b.address AS address,
        ic.category
    FROM
        businesses b
    JOIN
        iscategory ic ON b.business_id = ic.business_id
    WHERE
        b.city = '{city}' AND
        b.state = '{state}' AND
        ic.category = '{category.replace("'","''")}' AND
        (lower(b.name) LIKE '%{stext.lower()}%'
        {text_search})
    ORDER BY
        b.rating ASC
    LIMIT 200;
    """

    sql_query = text(sql)

    result = db.execute(sql_query, {"city": city, "state": state, "category": category})
    result_dict = [dict(row) for row in result]
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


# Existing endpoint for Query 1
@router.get("/states")
def states(db: Session = Depends(deps.get_db)):
    """Returns the list of distinct states from the businusses table in the db

    Args:
        db (Session, optional): a sqlalchemy Session object. Defaults to Depends(deps.get_db).

    Returns:
        [JSON]: an array of JSON objects (e.g. [{'state':'CA', 'state_desc':'California'}])
    """
    sql_query = text("""
    SELECT 
        DISTINCT state
    FROM 
        businesses
    WHERE state not in ('AB','XMS','VI')
    ORDER BY state
    """)
    result = db.execute(sql_query)
    result_dict = [dict(row) for row in result]
    # dist_st = set()
    for r in result_dict:
        # dist_st.add(r['state'])
        r['state_desc'] = state_abbreviations[r['state']]
    # print(dist_st)
    # #print(result_dict)
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


@router.get("/cities")
def cities(state: str, db: Session = Depends(deps.get_db)):
    """Returns the list of distinct available cities for a given state businesses table in the db

    Args:
        state (str): the 2 character state abbreviation code (e.g. CA)
        db (Session, optional): a sqlalchemy Session object. Defaults to Depends(deps.get_db).

    Returns:
        [JSON]: an array of JSON objects (e.g. [{'city':'Los Angeles'}, ..])
    """
    sql_query = text(f"""
    SELECT 
        DISTINCT city
    FROM 
        businesses
    WHERE state ='{state}'
    ORDER BY city;
    """)
    result = db.execute(sql_query)
    result_dict = [dict(row) for row in result]
    # #print(result_dict)
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


@router.get("/city-categories")
def city_categories(state: str, city: str, db: Session = Depends(deps.get_db)):
    """Returns the distinct business categories for a give City + State.
    Args:
        state (str): the 2 character state abbreviation code (e.g. 'CA')
        city (str): The name of a city in the state (e.g 'Los Angeles')
        db (Session, optional): a sqlalchemy Session object. Defaults to Depends(deps.get_db).

    Returns:
        [JSON]: an array of JSON objects (e.g. [{"category": "Accountants"}, ..])
    """
    sql_query = text(f"""
    select * from (SELECT DISTINCT b.category
    FROM businesses a
    JOIN iscategory b
    ON a.business_id = b.business_id
    WHERE a.state = '{state}' AND a.city = '{city}'

    union

    select distinct 'Hotels' as category
    from hotels
    where city ='{city}'
    and state='{state_abbreviations[state]}')
    order by category
    """)
    result = db.execute(sql_query)
    result_dict = [dict(row) for row in result]
    # #print(result_dict)
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


@router.get("/businesss_names")
def business_names(state: str = '', city: str = '', category: str = '', db: Session = Depends(deps.get_db)):
    """Returns the distinct business names from businesses table filtered by optional fields stae, city, category.
    Args:
        state (str, optional): the 2 character state abbreviation code (e.g. 'CA'). Defaults to ''.
        city (str, optional): The name of a city in the state (e.g 'Los Angeles'). Defaults to ''.
        category (str, optional): the category. Defaults to ''.
        db (Session, optional): a sqlalchemy Session object. Defaults to Depends(deps.get_db).

    Returns:
        [JSON]: an array of JSON objects (e.g. [{"category": "Accountants"}, ..])
    """
    sql_query = text(f"""
    select Distinct a.name from businesses a
    join iscategory b
    on a.business_id = b.business_id
    where a.state LIKE '%{state}%' and lower(a.city) LIKE lower('%{city}%') and lower(b.category) LIKE lower('%{category.replace("'","''")}%')
    """)
    result = db.execute(sql_query)
    result_dict = [dict(row) for row in result]
    # print(result_dict)
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


# Existing endpoint for Query 1
@router.get("/top_hotels", response_model=List[models.HotelBase])
def get_top_hotels(
        city: str,
        radius: float,
        top_n: int,
        db: Session = Depends(deps.get_db)
):
    sql_query = text("""
    SELECT 
        h.hotelcode, 
        h.hotelname, 
        AVG(r.stars) AS avg_nearby_restaurant_rating
    FROM 
        hotels h
    JOIN 
        businesses b ON b.city = h.city
    JOIN 
        iscategory ic ON b.business_id = ic.business_id
    JOIN 
        categories c ON ic.category_id = c.category_id
    JOIN 
        reviews r ON b.business_id = r.business_id
    WHERE 
        h.city = :city AND 
        c.category = 'Restaurants' AND
        (3959 * ACOS(
            COS(RADIANS(h.latitude)) * COS(RADIANS(b.latitude)) * 
            COS(RADIANS(b.longitude) - RADIANS(h.longitude)) + 
            SIN(RADIANS(h.latitude)) * SIN(RADIANS(b.latitude))
        )) <= :radius
    GROUP BY 
        h.hotelcode, h.hotelname
    ORDER BY 
        avg_nearby_restaurant_rating DESC
    LIMIT :top_n;
    """)
    result = db.execute(sql_query, {"city": city, "radius": radius, "top_n": top_n})
    result_dict = [dict(row) for row in result]
    # #print(result_dict)
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


# Endpoint for Query 2: Nearby Businesses Matching User Preferences
@router.get("/nearby_businesses", response_model=List[models.BusinessBase])
def get_nearby_businesses(
        hotelcode: int,
        radius: float,
        min_rating: float,
        categories: List[str] = Query(...),
        db: Session = Depends(deps.get_db)
):
    sql_query = text("""
    SELECT 
        b.business_id, 
        b.name, 
        AVG(r.stars) AS avg_rating
    FROM 
        hotels h
    JOIN 
        businesses b ON 1=1
    JOIN 
        iscategory ic ON b.business_id = ic.business_id
    JOIN 
        reviews r ON b.business_id = r.business_id
    WHERE 
        h.hotelcode = :hotelcode AND 
        ic.category = ANY(:categories) AND
        (3959 * ACOS(
            COS(RADIANS(h.latitude)) * COS(RADIANS(b.latitude)) *
            COS(RADIANS(b.longitude) - RADIANS(h.longitude)) +
            SIN(RADIANS(h.latitude)) * SIN(RADIANS(b.latitude))
        )) <= :radius
    GROUP BY 
        b.business_id, b.name
    HAVING 
        AVG(r.stars) >= :min_rating
    ORDER BY 
        avg_rating DESC;
    """)
    result = db.execute(
        sql_query,
        {
            "hotelcode": hotelcode,
            "radius": radius,
            "categories": categories,
            "min_rating": min_rating
        }
    )
    result_dict = [dict(row) for row in result]
    # #print(result_dict)
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


# Endpoint for Query 3: Hotels Near Businesses with the Most Reviews
@router.get("/hotels_near_popular_business", response_model=List[models.HotelBase])
def hotels_near_popular_business(
        city: str,
        radius: float,
        db: Session = Depends(deps.get_db)
):
    sql_query = text("""
    WITH top_business AS (
        SELECT 
            b.business_id, 
            b.latitude AS b_latitude, 
            b.longitude AS b_longitude
        FROM 
            businesses b
        JOIN 
            reviews r ON b.business_id = r.business_id
        WHERE 
            b.city = :city
        GROUP BY 
            b.business_id, b.latitude, b.longitude
        ORDER BY 
            COUNT(r.review_id) DESC
        LIMIT 1
    )
    SELECT 
        h.hotelcode, 
        h.hotelname,
        (3959 * ACOS(
            COS(RADIANS(h.latitude)) * COS(RADIANS(top_business.b_latitude)) *
            COS(RADIANS(top_business.b_longitude) - RADIANS(h.longitude)) +
            SIN(RADIANS(h.latitude)) * SIN(RADIANS(top_business.b_latitude))
        )) AS distance
    FROM 
        hotels h
    CROSS JOIN 
        top_business
    WHERE 
        (3959 * ACOS(
            COS(RADIANS(h.latitude)) * COS(RADIANS(top_business.b_latitude)) *
            COS(RADIANS(top_business.b_longitude) - RADIANS(h.longitude)) +
            SIN(RADIANS(h.latitude)) * SIN(RADIANS(top_business.b_latitude))
        )) <= :radius;
    """)
    result = db.execute(sql_query, {"city": city, "radius": radius})
    result_dict = [dict(row) for row in result]
    # #print(result_dict)
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


# Endpoint for Query 4: Hotel Closest to the Highest Rated Business in a Category
@router.get("/closest_hotel_to_top_business", response_model=models.HotelBase)
def closest_hotel_to_top_business(
        category: str,
        db: Session = Depends(deps.get_db)
):
    sql_query = text("""
    WITH top_business AS (
        SELECT 
            b.business_id, 
            b.latitude AS b_latitude, 
            b.longitude AS b_longitude
        FROM 
            businesses b
        JOIN 
            iscategory ic ON b.business_id = ic.business_id AND ic.category = :category
        JOIN 
            reviews r ON b.business_id = r.business_id
        GROUP BY 
            b.business_id, b.latitude, b.longitude
        ORDER BY 
            AVG(r.stars) DESC
        LIMIT 1
    )
    SELECT 
        h.hotelcode, 
        h.hotelname,
        (3959 * ACOS(
            COS(RADIANS(h.latitude)) * COS(RADIANS(top_business.b_latitude)) *
            COS(RADIANS(top_business.b_longitude) - RADIANS(h.longitude)) +
            SIN(RADIANS(h.latitude)) * SIN(RADIANS(top_business.b_latitude))
        )) AS distance
    FROM 
        hotels h
    CROSS JOIN 
        top_business
    ORDER BY 
        distance ASC
    LIMIT 1;
    """)
    result = db.execute(sql_query, {"category": category})
    row = result.fetchone()
    if row:
        result_dict = dict(row)
        # #print(result_dict)
        headers = {"Access-Control-Allow-Origin": "*"}
        return JSONResponse(content=result_dict, status_code=200, headers=headers)
    else:
        raise HTTPException(status_code=404, detail="No matching hotel found")


@router.get("/top_business_in_category_optimized")
def top_business_in_category_optimized(
        city: str,
        state: str,
        category: str = Query(..., description="Category to find the top business in"),
        db: Session = Depends(deps.get_db)
):
    sql = text("""
    WITH category_businesses AS (
        SELECT b.*, ic.category
        FROM businesses b
        JOIN iscategory ic ON b.business_id = ic.business_id
        WHERE ic.category = :category -- 'Nightlife'
        AND b.city = :city
        AND b.state = :state
    )
    SELECT DISTINCT
        b.business_id as id,
        b.name,
        b.latitude AS b_latitude,
        b.longitude AS b_longitude,
        b.rating,
        b.num_ratings,
        b.category
    FROM
        category_businesses b
    ORDER BY
        rating DESC, num_ratings desc;
    """)

    # Execute the query with the provided category parameter
    result = db.execute(sql, {"category": category, "city": city, "state": state})
    result_dict = [dict(row) for row in result]
    # print(result_dict)
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


# Endpoint for Query 5: Hotels Near Highly Rated Businesses in User-Preferred Categories
@router.get("/hotels_near_highly_rated_businesses", response_model=List[models.HotelBase])
def hotels_near_highly_rated_businesses(
        min_rating: float,
        radius: float,
        categories: List[str] = Query(...),
        db: Session = Depends(deps.get_db)
):
    sql_query = text("""
    SELECT DISTINCT 
        h.hotelcode, 
        h.hotelname
    FROM 
        hotels h
    JOIN 
        businesses b ON 1=1
    JOIN 
        iscategory ic ON b.business_id = ic.business_id
    JOIN 
        reviews r ON b.business_id = r.business_id
    WHERE 
        ic.category = ANY(:categories) AND
        (3959 * ACOS(
            COS(RADIANS(h.latitude)) * COS(RADIANS(b.latitude)) *
            COS(RADIANS(b.longitude) - RADIANS(h.longitude)) +
            SIN(RADIANS(h.latitude)) * SIN(RADIANS(b.latitude))
        )) <= :radius
    GROUP BY 
        h.hotelcode, h.hotelname, b.business_id
    HAVING 
        AVG(r.stars) >= :min_rating;
    """)
    result = db.execute(
        sql_query,
        {
            "categories": categories,
            "min_rating": min_rating,
            "radius": radius
        }
    )
    result_dict = [dict(row) for row in result]
    # #print(result_dict)
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


@router.get("/hotels_near_high_rated_businesses_optimized")
def hotels_near_high_rated_businesses_optimized(
        categories: List[str] = Query(...),
        min_rating: float = Query(3.0),
        radius: float = Query(10.0),

        db: Session = Depends(deps.get_db)
):
    sql = text("""
    WITH high_rated_businesses AS (
        SELECT
            b.business_id,
            b.latitude,
            b.longitude
        FROM
            businesses b
        WHERE
            EXISTS (
                SELECT 1
                FROM iscategory ic
                WHERE ic.business_id = b.business_id
                  AND ic.category = ANY(:categories)
            )
            AND EXISTS (
                SELECT 1
                FROM reviews r
                WHERE r.business_id = b.business_id
                GROUP BY r.business_id
                HAVING AVG(r.stars) >= :min_rating
            )
    )
    SELECT DISTINCT
        h.hotelcode,
        h.hotelname
    FROM
        high_rated_businesses b
    JOIN
        hotels h ON
            h.latitude BETWEEN b.latitude - (:radius / 69.0) AND b.latitude + (:radius / 69.0)
            AND h.longitude BETWEEN b.longitude - (:radius / (69.0 * COS(RADIANS(b.latitude)))) AND b.longitude + (:radius / (69.0 * COS(RADIANS(b.latitude))))
            AND (3959 * ACOS(
                COS(RADIANS(h.latitude)) * COS(RADIANS(b.latitude)) *
                COS(RADIANS(b.longitude) - RADIANS(h.longitude)) +
                SIN(RADIANS(h.latitude)) * SIN(RADIANS(b.latitude))
            )) <= :radius;
    """)

    # Prepare parameters
    params = {
        "categories": categories,
        "min_rating": min_rating,
        "radius": radius
    }

    # Execute the query
    result = db.execute(sql, params)
    result_list = [dict(row) for row in result]
    return JSONResponse(content=result_list, status_code=200)


# Endpoint for Query 6: Generate a Customized Itinerary Based on User Interests
@router.get("/custom_itinerary", response_model=List[models.BusinessBase])
def custom_itinerary(
        hotelcode: int,
        categories: List[str] = Query(...),
        db: Session = Depends(deps.get_db)
):
    sql_query = text("""
    SELECT 
        b.business_id, 
        b.name, 
        (3959 * ACOS(
            COS(RADIANS(h.latitude)) * COS(RADIANS(b.latitude)) *
            COS(RADIANS(b.longitude) - RADIANS(h.longitude)) +
            SIN(RADIANS(h.latitude)) * SIN(RADIANS(b.latitude))
        )) AS distance,
        AVG(r.stars) AS avg_rating
    FROM 
        hotels h
    JOIN 
        businesses b ON 1=1
    JOIN 
        iscategory ic ON b.business_id = ic.business_id
    JOIN 
        reviews r ON b.business_id = r.business_id
    WHERE 
        h.hotelcode = :hotelcode AND 
        ic.category = ANY(:categories)
    GROUP BY 
        b.business_id, b.name, h.latitude, h.longitude, b.latitude, b.longitude
    ORDER BY 
        distance ASC, 
        avg_rating DESC;
    """)
    result = db.execute(
        sql_query,
        {
            "hotelcode": hotelcode,
            "categories": categories
        }
    )
    result_dict = [dict(row) for row in result]
    # #print(result_dict)
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


# Endpoint for Query 7: Hotels with Nearby Businesses Matching All User Criteria
@router.get("/hotels_with_matching_businesses", response_model=List[models.HotelBase])
def hotels_with_matching_businesses(
        radius: float,
        min_rating: float,
        categories: List[str] = Query(...),
        db: Session = Depends(deps.get_db)
):
    sql_query = text("""
    SELECT DISTINCT 
        h.hotelcode, 
        h.hotelname
    FROM 
        hotels h
    JOIN 
        businesses b ON 1=1
    JOIN 
        iscategory ic ON b.business_id = ic.business_id
    JOIN 
        reviews r ON b.business_id = r.business_id
    WHERE 
        ic.category = ANY(:categories) AND
        (3959 * ACOS(
            COS(RADIANS(h.latitude)) * COS(RADIANS(b.latitude)) *
            COS(RADIANS(b.longitude) - RADIANS(h.longitude)) +
            SIN(RADIANS(h.latitude)) * SIN(RADIANS(b.latitude))
        )) <= :radius
    GROUP BY 
        h.hotelcode, h.hotelname, b.business_id
    HAVING 
        AVG(r.stars) >= :min_rating;
    """)
    result = db.execute(
        sql_query,
        {
            "categories": categories,
            "radius": radius,
            "min_rating": min_rating
        }
    )
    result_dict = [dict(row) for row in result]
    # #print(result_dict)
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


# Endpoint for Query 8: Identify Hotels Near Businesses with Exceptional Reviews
@router.get("/hotels_near_businesses_with_reviews", response_model=List[models.HotelBase])
def hotels_near_businesses_with_reviews(
        keyword: str,
        radius: float,
        db: Session = Depends(deps.get_db)
):
    sql_query = text("""
    SELECT DISTINCT 
        h.hotelcode, 
        h.hotelname
    FROM 
        hotels h
    JOIN 
        businesses b ON 1=1
    JOIN 
        reviews r ON b.business_id = r.business_id
    WHERE 
        r.text ILIKE '%' || :keyword || '%' AND
        (3959 * ACOS(
            COS(RADIANS(h.latitude)) * COS(RADIANS(b.latitude)) *
            COS(RADIANS(b.longitude) - RADIANS(h.longitude)) +
            SIN(RADIANS(h.latitude)) * SIN(RADIANS(b.latitude))
        )) <= :radius;
    """)
    result = db.execute(
        sql_query,
        {
            "keyword": keyword,
            "radius": radius
        }
    )
    result_dict = [dict(row) for row in result]
    # #print(result_dict)
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


# New Endpoint for Query 9: Closest Restaurants Near Given Latitude and Longitude with Rating Above Threshold

# @router.get("/top_nearest_businesses")
# def photos(city: str, state: str, distance: float, lat: float, lon: float, db: Session = Depends(deps.get_db)):

@router.get("/closest_restaurants")
def photos(category: str, distance: float, lat: float, lon: float, db: Session = Depends(deps.get_db)):
    sql_query = text("""
    WITH categories as (SELECT * FROM iscategory WHERE category = :category) , is_near AS (
        SELECT
            b.*,
    ( 3959 *
    acos( cos( radians(:latitude) ) *
    cos( radians( latitude ) ) *
    cos( radians( longitude ) -
    radians(:longitude) ) +
    sin( radians(:latitude) ) *
    sin( radians( latitude ) ) )
    ) AS distance
        FROM
            businesses b where exists(select c.* from categories c where b.business_id = c.business_id)
    )
    SELECT
        b.business_id as id,
        b.name,
        b.address,
        b.city,
        b.state,
        b.zipcode,
        b.latitude,
        b.longitude,
        ic.category,
        r.rating,
        r.num_ratings,
        b.distance
    FROM
        is_near b

    JOIN
        categories ic ON b.business_id = ic.business_id
    JOIN
        reviews_summary r ON b.business_id = r.business_id
    WHERE
        b.distance <= :radius
        AND r.rating > :stars
    ORDER BY
        b.distance ASC
    LIMIT :top_n;
    """)
    result = db.execute(sql_query,
        {
            "category": category,
            "latitude": lat,
            "longitude": lon,
            "radius": distance,
            "stars": 1,
            "top_n": 10
        }
    )
    result_dict = [dict(row) for row in result]
    # #print(result_dict)
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


# New Endpoint for Query 10: Nearby Restaurants with Average Rating and Number of Reviews Above Thresholds
@router.get("/nearby_restaurants_with_reviews", response_model=List[models.BusinessBase])
def nearby_restaurants_with_reviews(
        latitude: float,
        longitude: float,
        radius: float,
        stars: float,
        num_reviews: int,
        db: Session = Depends(deps.get_db)
):
    sql_query = text("""
    WITH is_near AS (
        SELECT
            b.*,
            (3959 * ACOS(
                COS(RADIANS(:latitude)) * COS(RADIANS(b.latitude)) * 
                COS(RADIANS(b.longitude) - RADIANS(:longitude)) + 
                SIN(RADIANS(:latitude)) * SIN(RADIANS(b.latitude))
            )) AS distance
        FROM
            businesses b
    ),
    num_reviews_cte AS (
        SELECT 
            business_id, COUNT(*) AS review_count 
        FROM 
            reviews
        GROUP BY 
            business_id
    )
    SELECT
        b.*, ic.category, r.stars, n.review_count
    FROM
        is_near b
    JOIN
        (SELECT * FROM iscategory WHERE category = 'Restaurants') ic ON b.business_id = ic.business_id
    JOIN
        (SELECT business_id, AVG(stars) AS stars FROM reviews GROUP BY business_id) r ON b.business_id = r.business_id
    JOIN
        num_reviews_cte n ON b.business_id = n.business_id
    WHERE
        b.distance <= :radius
        AND r.stars > :stars
        AND n.review_count > :num_reviews
    ORDER BY
        b.distance ASC;
    """)
    result = db.execute(
        sql_query,
        {
            "latitude": latitude,
            "longitude": longitude,
            "radius": radius,
            "stars": stars,
            "num_reviews": num_reviews
        }
    )
    result_dict = [dict(row) for row in result]
    # #print(result_dict)
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


# # New Endpoint: Fetch Distinct States
# @router.get("/states", response_model=List[str])
# def get_states(db: Session = Depends(deps.get_db)):
#     """Fetch all distinct states."""
#     sql_query = text("""
#     SELECT DISTINCT state
#     FROM businesses
#     ORDER BY state;
#     """)
#     result = db.execute(sql_query).fetchall()
#     return [row[0] for row in result]  # Extract state values


# # New Endpoint: Fetch Distinct Cities by State
# @router.get("/cities", response_model=List[str])
# def get_cities(state: str, db: Session = Depends(deps.get_db)):
#     """Fetch distinct cities for a given state."""
#     if not state:
#         raise HTTPException(status_code=400, detail="State is required")
#     sql_query = text("""
#     SELECT DISTINCT city
#     FROM businesses
#     WHERE state = :state
#     ORDER BY city;
#     """)
#     result = db.execute(sql_query, {"state": state}).fetchall()
#     return [row[0] for row in result]  # Extract city values


# New Endpoint: Fetch Distinct Categories
@router.get("/categories", response_model=List[str])
def get_categories(db: Session = Depends(deps.get_db)):
    """Fetch all distinct categories."""
    sql_query = text("""
    SELECT DISTINCT category
    FROM categories
    ORDER BY category;
    """)
    result = db.execute(sql_query).fetchall()
    result_dict = [dict(row) for row in result]
    # #print(result_dict)
    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


@router.get("/top_nearest_businesses")
def photos(city: str, state: str, distance: float, lat: float, lon: float, db: Session = Depends(deps.get_db)):
    """Returns the list of photo identifiers belonging to the business with business id

    Args:
        hcode (str): a hotel code
        ccode (str): a city code
        db (Session, optional): a sqlalchemy Session object. Defaults to Depends(deps.get_db).

    Returns:
        [JSON]: an array of JSON objects (e.g. [{'state':'CA', 'state_desc':'California'}])
    """
    if len(state) > 2:
        for key, value in state_abbreviations.items():
            if value == state:
                state = key
                break

    sql_query = text(f"""
    WITH category_businesses as (
    SELECT
        b.business_id as id,
        b.name,
        b.address,
        b.city,
        b.state,
        b.zipcode,
        b.latitude,
        b.longitude,
        rs.rating,
        rs.num_ratings,
        ( 3959 *
        acos( cos( radians({lat}) ) *
        cos( radians( latitude ) ) *
        cos( radians( longitude ) -
        radians({lon}) ) +
        sin( radians({lat}) ) *
        sin( radians( latitude ) ) )
        ) AS distance
    FROM
        businesses b
    join reviews_summary rs on b.business_id = rs.business_id
    )
    SELECT
        id,
        name,
        address,
        city,
        state,
        zipcode,
        latitude,
        longitude,
        rating,
        num_ratings,
        distance
    FROM category_businesses
    WHERE distance <= {distance}
    ORDER BY rating desc, distance asc, num_ratings desc
    LIMIT 10;
    """)
    result = db.execute(sql_query)
    result_dict = [dict(row) for row in result]

    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


@router.get("/top_nearest_hotels")
def photos(distance: float, lat: float, lon: float, db: Session = Depends(deps.get_db)):
    """Returns the list of photo identifiers belonging to the business with business id

    Args:
        hcode (str): a hotel code
        ccode (str): a city code
        db (Session, optional): a sqlalchemy Session object. Defaults to Depends(deps.get_db).

    Returns:
        [JSON]: an array of JSON objects (e.g. [{'state':'CA', 'state_desc':'California'}])
    """
    sql_query = text(f"""
    with hotel_distance as (SELECT  a.*,
       ( 3959 *
            acos( cos( radians({lat}) ) *
            cos( radians( latitude ) ) *
            cos( radians( longitude ) -
            radians({lon}) ) +
            sin( radians({lat}) ) *
            sin( radians( latitude ) ) )
        ) AS distance
    FROM  hotels a)

    select         
        hotelcode AS id,
        hotelname AS name,
        hotelrating AS rating,
        address AS address,
        citycode,
        distance 
    from hotel_distance 
    where distance <= {distance}
    order by hotelrating desc, distance asc
    limit 10;
    """)
    result = db.execute(sql_query)
    result_dict = [dict(row) for row in result]

    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


@router.get("/top_nearest_category_businesses")
def photos(category: str, distance: float, lat: float, lon: float, db: Session = Depends(deps.get_db)):
    """Returns the list of photo identifiers belonging to the business with business id

    Args:
        hcode (str): a hotel code
        ccode (str): a city code
        db (Session, optional): a sqlalchemy Session object. Defaults to Depends(deps.get_db).

    Returns:
        [JSON]: an array of JSON objects (e.g. [{'state':'CA', 'state_desc':'California'}])
    """
    sql_query = text(f"""
    WITH category_businesses as (
    SELECT
        b.business_id as id,
        b.name,
        b.address,
        b.city,
        b.state,
        b.zipcode,
        b.latitude,
        b.longitude,
        rs.rating,
        rs.num_ratings,
        ic.category,
        ( 3959 *
        acos( cos( radians({lat}) ) *
        cos( radians( latitude ) ) *
        cos( radians( longitude ) -
        radians({lon}) ) +
        sin( radians({lat}) ) *
        sin( radians( latitude ) ) )
        ) AS distance
    FROM
        businesses b
    JOIN
        isCategory ic
    ON b.business_id = ic.business_id
    join reviews_summary rs on b.business_id = rs.business_id
    WHERE ic.category = '{category.replace("'","''")}')
    SELECT
        id,
        name,
        address,
        city,
        state,
        zipcode,
        latitude,
        longitude,
        category,
        rating,
        num_ratings,
        distance
    FROM category_businesses
    WHERE
    distance <= {distance}
    ORDER BY rating desc, distance asc, num_ratings desc
    limit 10;
    """)
    result = db.execute(sql_query)
    result_dict = [dict(row) for row in result]

    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)


@router.get("/reviews")
def photos(bid: str, page: int, page_size: int, db: Session = Depends(deps.get_db)):
    """Returns the list of photo identifiers belonging to the business with business id

    Args:
        hcode (str): a hotel code
        ccode (str): a city code
        db (Session, optional): a sqlalchemy Session object. Defaults to Depends(deps.get_db).

    Returns:
        [JSON]: an array of JSON objects (e.g. [{'state':'CA', 'state_desc':'California'}])
    """
    sql_query = text(f"""
    select 
    review_id,
    business_id,
    stars,
    text,
    name,
    Cast(date as varchar) as date
    from reviews
    where business_id = '{bid}'
    order by date desc
    LIMIT {page_size} OFFSET {(page - 1) * page_size}
    """)
    result = db.execute(sql_query)
    result_dict = [dict(row) for row in result]
    # print(result_dict)

    headers = {"Access-Control-Allow-Origin": "*"}
    return JSONResponse(content=result_dict, status_code=200, headers=headers)
