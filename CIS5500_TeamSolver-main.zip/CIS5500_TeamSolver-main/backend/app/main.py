# app/main.py

from fastapi import FastAPI
from app.api.v1 import queries

app = FastAPI(title="Teamsolver", version="1.0.0")

app.include_router(
    queries.router,
    prefix="/api/v1",
    tags=["queries"]
)
