# app/models/hotel.py

from sqlalchemy import Column, Integer, String, Float
from app.db.base_class import Base


class Hotel(Base):
    hotelcode = Column(Integer, primary_key=True, index=True)
    latitude = Column(Float)
    longitude = Column(Float)
    city = Column(String(255))
    state = Column(String(255))
    zipcode = Column(String(255))
    hotelname = Column(String(255))
