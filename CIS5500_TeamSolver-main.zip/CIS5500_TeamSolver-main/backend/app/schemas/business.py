# app/schemas/business.py

from sqlalchemy import Column, String, Float
from sqlalchemy.orm import relationship
from app.db.base_class import Base


class Business(Base):
    business_id = Column(String(255), primary_key=True, index=True)
    name = Column(String(255))
    address = Column(String(255))
    city = Column(String(255))
    state = Column(String(255))
    zipcode = Column(String(255))
    latitude = Column(Float)
    longitude = Column(Float)

    reviews = relationship("Review", back_populates="business")
    categories = relationship("IsCategory", back_populates="business")
