# app/schemas/category.py

from sqlalchemy import Column, String
from app.db.base_class import Base


class Category(Base):
    category_id = Column(String(255), primary_key=True, index=True)
    category = Column(String(255))
