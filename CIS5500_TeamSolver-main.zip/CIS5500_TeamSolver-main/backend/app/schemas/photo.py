# app/schemas/photo.py

from sqlalchemy import Column, String, ForeignKey
from app.db.base_class import Base


class Photo(Base):
    photo_id = Column(String(255), primary_key=True, index=True)
    business_id = Column(String(255), ForeignKey("business.business_id"))
