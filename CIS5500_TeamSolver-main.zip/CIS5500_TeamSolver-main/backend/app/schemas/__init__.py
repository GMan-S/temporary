# app/schemas/__init__.py

from .hotel import Hotel
from .business import Business
from .review import Review
from .category import Category
from .is_category import IsCategory
from .photo import Photo
