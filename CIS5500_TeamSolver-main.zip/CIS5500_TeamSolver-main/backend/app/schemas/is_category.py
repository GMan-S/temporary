# app/schemas/is_category.py

from sqlalchemy import Column, String, ForeignKey
from sqlalchemy.orm import relationship
from app.db.base_class import Base


class IsCategory(Base):
    business_id = Column(String(255), ForeignKey("business.business_id"), primary_key=True)
    category_id = Column(String(255), ForeignKey("category.category_id"), primary_key=True)
    category = Column(String(255))

    business = relationship("Business", back_populates="categories")
    category_rel = relationship("Category")
