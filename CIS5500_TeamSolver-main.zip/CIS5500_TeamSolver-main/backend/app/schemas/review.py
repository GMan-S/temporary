# app/schemas/review.py

from sqlalchemy import Column, String, Integer, ForeignKey
from sqlalchemy.orm import relationship
from app.db.base_class import Base


class Review(Base):
    review_id = Column(String(255), primary_key=True, index=True)
    business_id = Column(String(255), ForeignKey("business.business_id"))
    stars = Column(Integer)
    text = Column(String(255))

    business = relationship("Business", back_populates="reviews")
